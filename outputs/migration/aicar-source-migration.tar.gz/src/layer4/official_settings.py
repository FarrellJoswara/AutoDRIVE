"""Authoritative Layer 4 settings for official-simulator PPO runs."""

from __future__ import annotations

import math
import sys
from typing import Literal, Optional
import json
from pathlib import Path

from pydantic import BaseModel, ConfigDict, Field

from src.layer4.settings import ROOT


OFFICIAL_SETTINGS_PATH = ROOT / "logs" / "layer4" / "official_train_settings.json"


def _default_simulator_backend() -> Literal["docker", "windows_external", "macos_external"]:
    if sys.platform == "darwin":
        return "macos_external"
    return "windows_external"


def _default_observation_profile() -> Literal[
    "official_sensors", "official_sensors_history", "official_sensors_camera"
]:
    if sys.platform == "darwin":
        return "official_sensors"
    return "official_sensors_camera"


def _default_display_mode() -> Literal["gui", "offscreen"]:
    if sys.platform == "darwin":
        return "offscreen"
    return "gui"


class OfficialTrainSettings(BaseModel):
    """Competition settings accepted by the official-only run manager.

    Run identity, output directory, simulator ports, and container names are
    assigned by Layer 4 and intentionally cannot be supplied here.
    """

    # Zero means no timestep ceiling; plateau and optional wall-clock stop rules still apply.
    simulator_backend: Literal["docker", "windows_external", "macos_external"] = Field(
        default_factory=_default_simulator_backend
    )
    # Windows offscreen keeps the GPU graphics device; macOS offscreen uses batch/nographics.
    simulator_display_mode: Literal["gui", "offscreen"] = Field(default_factory=_default_display_mode)
    # None preserves the backend's legacy route. Explicit profiles pin the route
    # independently of image labels and are verified against the runtime scene.
    track_profile: Optional[Literal["competition", "practice"]] = None
    simulator_executable: Optional[str] = None
    # Opt-in native official-run safeguard. Zero preserves legacy watchdog
    # behavior; enabled values neutralize both actuators before the 250 ms lease.
    safe_neutral_fallback_s: float = Field(default=0.0, ge=0.0, lt=0.25)
    n_envs: int = Field(default=1, ge=1, le=8)
    total_timesteps: int = Field(default=1_000_000, ge=0)
    stop_on_plateau: bool = True
    plateau_min_timesteps: int = Field(default=100_000, ge=0)
    plateau_window_episodes: int = Field(default=5, ge=2, le=100)
    plateau_patience: int = Field(default=5, ge=1, le=100)
    plateau_min_improvement_pct: float = Field(default=1.0, ge=0, le=100)
    max_duration_hours: float = Field(default=0.0, ge=0)
    # Campaign experiment metadata is validated against the append-only campaign
    # ledger by the hub. These tags do not change trainer behavior; the actual
    # effective settings below remain the submitted experiment configuration.
    campaign_experiment_id: Optional[str] = None
    campaign_experiment_phase: Optional[str] = None
    campaign_experiment_config_sha256: Optional[str] = None
    seed: int = Field(default=0, ge=0, le=2**31 - 1)
    device: Literal["cpu", "cuda"] = "cpu"
    resume: Optional[str] = None
    checkpoint_every: int = Field(default=10_000, ge=1)
    automatic_evaluation_enabled: bool = Field(default_factory=lambda: sys.platform != "darwin")
    automatic_evaluation_trigger: Literal["steps", "episodes"] = "steps"
    automatic_evaluation_interval: int = Field(default=50_000, ge=1)
    automatic_evaluation_mode: Literal["competitive", "training_probe"] = "competitive"
    behavior_cloning_enabled: bool = True
    behavior_cloning_only: bool = False
    behavior_cloning_collect_only: bool = False
    behavior_cloning_clean_laps: int = Field(default=10, ge=1, le=100)
    behavior_cloning_required_clean_episodes: int = Field(default=2, ge=1, le=100)
    behavior_cloning_wall_timeout_s: float = Field(default=1800.0, gt=0, le=86400)
    behavior_cloning_steps_per_env: int = Field(default=4000, ge=2, le=100_000)
    behavior_cloning_epochs: int = Field(default=8, ge=1, le=100)
    behavior_cloning_batch_size: int = Field(default=256, ge=8, le=4096)
    behavior_cloning_learning_rate: float = Field(default=1e-3, gt=0, le=0.1)
    behavior_teacher_max_speed_mps: float = Field(default=0.3, ge=0.2, le=10.0)
    n_steps: int = Field(default=2048, ge=64, multiple_of=64)
    learning_rate: float = Field(default=1e-4, gt=0, le=0.01)
    target_kl: Optional[float] = Field(default=None, gt=0)
    exploration_profile: Optional[Literal["standard", "bc_smoke", "bc_campaign"]] = None
    exploration_initial_std_throttle: Optional[float] = Field(default=None, gt=0)
    exploration_initial_std_steering: Optional[float] = Field(default=None, gt=0)
    exploration_min_std_throttle: Optional[float] = Field(default=None, gt=0)
    exploration_min_std_steering: Optional[float] = Field(default=None, gt=0)
    exploration_max_std_throttle: Optional[float] = Field(default=None, gt=0)
    exploration_max_std_steering: Optional[float] = Field(default=None, gt=0)
    n_epochs: int = Field(default=4, ge=1, le=20)
    gamma: float = Field(default=0.9995, gt=0, le=1)
    gae_lambda: float = Field(default=0.95, ge=0, le=1)
    timeout_s: float = Field(default=30.0, gt=0)
    training_timeout_s: float = Field(default=600.0, gt=0)
    frontier_stagnation_s: float = Field(default=5.0, ge=0)
    race_laps: int = Field(default=10, ge=1, le=100)
    warmup_laps: int = Field(default=0, ge=0, le=20)
    time_cost_per_simulated_second: float = Field(default=0.0, ge=0)
    collision_penalty_magnitude: float = Field(default=200.0, ge=121)
    collision_reward_percent: float = Field(default=0.0, ge=0, le=100)
    lap_completion_reward: float = Field(default=0.0, ge=0, le=0)
    failed_episode_penalty: float = Field(default=200.0, ge=121)
    backward_speed_penalty_scale: float = Field(default=10.0, ge=0)
    episode_failure_reward_percent: float = Field(default=0.0, ge=0, le=100)
    observation_profile: Literal[
        "official_sensors", "official_sensors_history", "official_sensors_camera"
    ] = Field(default_factory=_default_observation_profile)
    steering_action_scale: float = Field(default=1.0, ge=0, le=1)
    straight_throttle_gain: float = Field(default=1.0, ge=1, le=2)
    straight_throttle_steering_threshold: float = Field(default=0.15, ge=0, le=1)
    throttle_mode: Literal["bidirectional", "forward_only"] = "bidirectional"
    negative_throttle_mode: Literal["allow", "zero", "positive_magnitude"] = "allow"
    steering_mode: Literal["normal", "invert"] = "normal"

    def to_container_env(self, *, hub_url: str, run_id: str) -> dict[str, str]:
        """Build the exact trainer environment for one manager-assigned run."""
        values = {
            "AICAR_MODE": "train",
            "AICAR_SIMULATOR_BACKEND": self.simulator_backend,
            "AICAR_OFFICIAL_SAFE_NEUTRAL_FALLBACK_S": str(self.safe_neutral_fallback_s),
            "AICAR_TRAIN_N_ENVS": str(self.n_envs),
            "HUB_URL": hub_url,
            "AICAR_RUN_ID": run_id,
            "AICAR_TRAIN_OUT": f"/runs/rl/official_run_{run_id}",
            "AICAR_TRAIN_TIMESTEPS": str(self.total_timesteps),
            "AICAR_TRAIN_STOP_ON_PLATEAU": "1" if self.stop_on_plateau else "0",
            "AICAR_TRAIN_PLATEAU_MIN_TIMESTEPS": str(self.plateau_min_timesteps),
            "AICAR_TRAIN_PLATEAU_WINDOW_EPISODES": str(self.plateau_window_episodes),
            "AICAR_TRAIN_PLATEAU_PATIENCE": str(self.plateau_patience),
            "AICAR_TRAIN_PLATEAU_MIN_IMPROVEMENT_PCT": str(self.plateau_min_improvement_pct),
            "AICAR_TRAIN_MAX_DURATION_HOURS": str(self.max_duration_hours),
            "AICAR_TRAIN_SEED": str(self.seed),
            "AICAR_PPO_DEVICE": self.device,
            "AICAR_TRAIN_CHECKPOINT_EVERY": str(self.checkpoint_every),
            "AICAR_AUTO_EVALUATION_ENABLED": "1" if self.automatic_evaluation_enabled else "0",
            "AICAR_AUTO_EVALUATION_TRIGGER": self.automatic_evaluation_trigger,
            "AICAR_AUTO_EVALUATION_INTERVAL": str(self.automatic_evaluation_interval),
            "AICAR_AUTO_EVALUATION_MODE": self.automatic_evaluation_mode,
            "AICAR_BEHAVIOR_CLONING_ENABLED": "1" if self.behavior_cloning_enabled else "0",
            "AICAR_BEHAVIOR_CLONING_ONLY": "1" if self.behavior_cloning_only else "0",
            "AICAR_BEHAVIOR_CLONING_COLLECT_ONLY": "1" if self.behavior_cloning_collect_only else "0",
            "AICAR_BEHAVIOR_CLONING_CLEAN_LAPS": str(self.behavior_cloning_clean_laps),
            "AICAR_BEHAVIOR_CLONING_REQUIRED_CLEAN_EPISODES": str(self.behavior_cloning_required_clean_episodes),
            "AICAR_BEHAVIOR_CLONING_WALL_TIMEOUT_S": str(self.behavior_cloning_wall_timeout_s),
            "AICAR_BEHAVIOR_CLONING_STEPS_PER_ENV": str(self.behavior_cloning_steps_per_env),
            "AICAR_BEHAVIOR_CLONING_EPOCHS": str(self.behavior_cloning_epochs),
            "AICAR_BEHAVIOR_CLONING_BATCH_SIZE": str(self.behavior_cloning_batch_size),
            "AICAR_BEHAVIOR_CLONING_LEARNING_RATE": str(self.behavior_cloning_learning_rate),
            "AICAR_BEHAVIOR_TEACHER_MAX_SPEED_MPS": str(self.behavior_teacher_max_speed_mps),
            "AICAR_PPO_N_STEPS": str(self.n_steps),
            "AICAR_PPO_LEARNING_RATE": str(self.learning_rate),
            "AICAR_PPO_N_EPOCHS": str(self.n_epochs),
            "AICAR_PPO_GAMMA": str(self.gamma),
            "AICAR_PPO_GAE_LAMBDA": str(self.gae_lambda),
            "AICAR_SENSOR_TIMEOUT_S": str(self.timeout_s),
            "AICAR_TRAIN_WATCHDOG_S": str(self.training_timeout_s),
            "AICAR_TRAIN_FRONTIER_STAGNATION_S": str(self.frontier_stagnation_s),
            "AICAR_TRAIN_RACE_LAPS": str(self.race_laps),
            "AICAR_TRAIN_WARMUP_LAPS": str(self.warmup_laps),
            "AICAR_TRAIN_TIME_COST": str(self.time_cost_per_simulated_second),
            "AICAR_TRAIN_COLLISION_PENALTY_MAGNITUDE": str(self.collision_penalty_magnitude),
            "AICAR_TRAIN_COLLISION_REWARD_PERCENT": str(self.collision_reward_percent),
            "AICAR_TRAIN_LAP_COMPLETION_REWARD": str(self.lap_completion_reward),
            "AICAR_TRAIN_FAILURE_PENALTY": str(self.failed_episode_penalty),
            "AICAR_TRAIN_BACKWARD_SPEED_PENALTY_SCALE": str(self.backward_speed_penalty_scale),
            "AICAR_TRAIN_FAILURE_REWARD_PERCENT": str(self.episode_failure_reward_percent),
            "AICAR_OBSERVATION_PROFILE": self.observation_profile,
            "AICAR_STEERING_ACTION_SCALE": str(self.steering_action_scale),
            "AICAR_STRAIGHT_THROTTLE_GAIN": str(self.straight_throttle_gain),
            "AICAR_STRAIGHT_THROTTLE_STEERING_THRESHOLD": str(self.straight_throttle_steering_threshold),
            "AICAR_THROTTLE_MODE": self.throttle_mode,
            "AICAR_NEGATIVE_THROTTLE_MODE": self.negative_throttle_mode,
            "AICAR_STEERING_MODE": self.steering_mode,
        }
        if self.track_profile is not None:
            values["AICAR_OFFICIAL_TRACK_PROFILE"] = self.track_profile
        if self.simulator_executable:
            values["AICAR_OFFICIAL_SIMULATOR_EXE"] = self.simulator_executable
        if self.target_kl is not None:
            values["AICAR_PPO_TARGET_KL"] = str(self.target_kl)
        if self.exploration_profile is not None:
            values["AICAR_PPO_EXPLORATION_PROFILE"] = self.exploration_profile
        for field_name, env_name in (
            ("exploration_initial_std_throttle", "AICAR_PPO_EXPLORATION_INITIAL_STD_THROTTLE"),
            ("exploration_initial_std_steering", "AICAR_PPO_EXPLORATION_INITIAL_STD_STEERING"),
            ("exploration_min_std_throttle", "AICAR_PPO_EXPLORATION_MIN_STD_THROTTLE"),
            ("exploration_min_std_steering", "AICAR_PPO_EXPLORATION_MIN_STD_STEERING"),
            ("exploration_max_std_throttle", "AICAR_PPO_EXPLORATION_MAX_STD_THROTTLE"),
            ("exploration_max_std_steering", "AICAR_PPO_EXPLORATION_MAX_STD_STEERING"),
        ):
            value = getattr(self, field_name)
            if value is not None:
                values[env_name] = str(value)
        if self.resume:
            values["AICAR_TRAIN_RESUME"] = self.resume
        return values
    model_config = ConfigDict(extra="forbid", allow_inf_nan=False)


def validate_bc_teacher_action_mapping(
    *,
    behavior_cloning_enabled: bool,
    resume: Optional[str],
    throttle_mode: str,
    negative_throttle_mode: str,
    steering_mode: str,
    steering_action_scale: float,
    straight_throttle_gain: float,
) -> None:
    """Require identity actuator mapping while raw teacher actions are labels."""
    if not behavior_cloning_enabled or resume is not None:
        return
    identity = (
        throttle_mode == "bidirectional"
        and negative_throttle_mode == "allow"
        and steering_mode == "normal"
        and math.isclose(float(steering_action_scale), 1.0, rel_tol=0.0, abs_tol=1e-12)
        and math.isclose(float(straight_throttle_gain), 1.0, rel_tol=0.0, abs_tol=1e-12)
    )
    if not identity:
        raise ValueError(
            "behavior cloning requires identity action transforms so teacher labels "
            "match executed controls; use bidirectional throttle, allow negative "
            "throttle, normal steering, steering scale 1, and straight throttle gain 1"
        )


def load_official_train_settings(path: Path = OFFICIAL_SETTINGS_PATH) -> OfficialTrainSettings:
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return OfficialTrainSettings()
    if isinstance(raw, dict):
        # Older settings included obsolete escalating collision and lidar
        # braking controls. Preserve explicit user choices in other fields.
        legacy_reward_schema = "collision_penalty_base" in raw or "lidar_brake_distance_m" in raw
        for legacy in ("collision_penalty_base", "lidar_brake_distance_m"):
            raw.pop(legacy, None)
        if sys.platform == "darwin":
            # This Mac host trains against the native practice .app, not Docker/Windows.
            if raw.get("simulator_backend") in {None, "docker", "windows_external"}:
                raw["simulator_backend"] = "macos_external"
            if raw.get("observation_profile") == "official_sensors_camera":
                raw["observation_profile"] = "official_sensors"
            raw.setdefault("simulator_display_mode", "offscreen")
            if "automatic_evaluation_enabled" not in raw:
                raw["automatic_evaluation_enabled"] = False
        if legacy_reward_schema:
            raw.update({
                "warmup_laps": 0,
                "time_cost_per_simulated_second": 0.0,
                "collision_penalty_magnitude": 200.0,
                "collision_reward_percent": 0.0,
                "failed_episode_penalty": 200.0,
                "backward_speed_penalty_scale": 10.0,
                "episode_failure_reward_percent": 0.0,
                "frontier_stagnation_s": 5.0,
            })
        incompatible_reward_settings = (
            float(raw.get("collision_penalty_magnitude", 200.0)) <= 120.0
            or float(raw.get("failed_episode_penalty", 200.0)) <= 120.0
            or float(raw.get("collision_reward_percent", 0.0)) > 0.0
            or float(raw.get("episode_failure_reward_percent", 0.0)) > 0.0
            or float(raw.get("lap_completion_reward", 0.0)) > 0.0
        )
        # A previous run config can carry 100-point penalties and 100% return
        # clawback. The current safe-progress objective needs a fixed cost above
        # its bounded 120-point progress and centerline budget, with progress
        # left credited to the life that earned it.
        if float(raw.get("collision_penalty_magnitude", 200.0)) <= 120.0:
            raw["collision_penalty_magnitude"] = 200.0
        if float(raw.get("failed_episode_penalty", 200.0)) <= 120.0:
            raw["failed_episode_penalty"] = 200.0
        if incompatible_reward_settings:
            raw["time_cost_per_simulated_second"] = 0.0
            raw["collision_reward_percent"] = 0.0
            raw["episode_failure_reward_percent"] = 0.0
            raw["lap_completion_reward"] = 0.0
    return OfficialTrainSettings.model_validate(raw)


def save_official_train_settings(
    settings: OfficialTrainSettings, path: Path = OFFICIAL_SETTINGS_PATH
) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + ".tmp")
    temp.write_text(settings.model_dump_json(indent=2), encoding="utf-8")
    temp.replace(path)
    return path
