"""Mission Control FastAPI hub."""
