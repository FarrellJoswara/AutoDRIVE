"""Stateful, forward-only projection of a car onto a map centerline."""

from __future__ import annotations

import csv
import math
import time
from pathlib import Path
from typing import Optional, Sequence, Tuple

import numpy as np


class RouteProgressTracker:
    """Project poses onto an ordered route and expose its across-track frontier.

    ``frontier_s`` is monotonic for the lifetime of an episode. Projection after
    initialization is constrained to a short window ahead of the frontier, so a
    nearby later section cannot award a large progress jump after a shortcut.
    """

    def __init__(
        self,
        points: np.ndarray,
        widths_right: Optional[np.ndarray] = None,
        widths_left: Optional[np.ndarray] = None,
        *,
        max_forward_m: float = 2.0,
        backward_tolerance_m: float = 0.5,
        max_lateral_m: float = 3.0,
        min_push_m: float = 0.04,
    ) -> None:
        pts = np.asarray(points, dtype=np.float64)
        if pts.ndim != 2 or pts.shape[1] != 2 or len(pts) < 3:
            raise ValueError("centerline must contain at least three 2D points")
        if not np.all(np.isfinite(pts)):
            raise ValueError("centerline contains non-finite coordinates")

        seg = np.diff(pts, axis=0)
        lengths = np.linalg.norm(seg, axis=1)
        keep = lengths > 1e-6
        self.points = pts
        self._seg = seg
        self._lengths = lengths
        self._cum = np.concatenate(([0.0], np.cumsum(lengths)))
        self.length_m = float(self._cum[-1])
        self.closed = bool(np.linalg.norm(pts[0] - pts[-1]) <= 0.5)
        if self.closed:
            close_seg = pts[0] - pts[-1]
            close_len = float(np.linalg.norm(close_seg))
            if close_len > 1e-6:
                self.points = np.vstack((pts, pts[0]))
                self._seg = np.vstack((seg, close_seg))
                self._lengths = np.append(lengths, close_len)
                self._cum = np.concatenate(([0.0], np.cumsum(self._lengths)))
                self.length_m = float(self._cum[-1])

        if self.length_m <= 1e-3 or not np.any(keep):
            raise ValueError("centerline has no usable route length")

        n = len(self.points)
        self.widths_right = self._prepare_widths(widths_right, n)
        self.widths_left = self._prepare_widths(widths_left, n)
        self.max_forward_m = max(0.1, float(max_forward_m))
        self.backward_tolerance_m = max(0.0, float(backward_tolerance_m))
        self.max_lateral_m = max(0.1, float(max_lateral_m))
        self.min_push_m = max(0.0, float(min_push_m))
        self.frontier_s: Optional[float] = None
        # The car's current route coordinate can move in either direction;
        # frontier_s remains the monotonic best-so-far coordinate.
        self.current_s: Optional[float] = None
        self.last_push_time: Optional[float] = None
        self.last_time: Optional[float] = None
        self.frontier_speed_mps = 0.0

    @classmethod
    def from_csv(cls, path: Path, **kwargs: float) -> "RouteProgressTracker":
        rows = []
        with Path(path).open("r", encoding="utf-8", newline="") as f:
            for row in csv.reader(line for line in f if not line.lstrip().startswith("#")):
                if not row:
                    continue
                try:
                    rows.append([float(value) for value in row[:4]])
                except (ValueError, TypeError):
                    continue
        if len(rows) < 3:
            raise ValueError(f"centerline CSV has fewer than three points: {path}")
        data = np.asarray(rows, dtype=np.float64)
        right = data[:, 2] if data.shape[1] > 2 else None
        left = data[:, 3] if data.shape[1] > 3 else None
        return cls(data[:, :2], right, left, **kwargs)

    @staticmethod
    def _prepare_widths(widths: Optional[np.ndarray], n: int) -> np.ndarray:
        if widths is None:
            return np.full(n, 0.5, dtype=np.float64)
        values = np.asarray(widths, dtype=np.float64).reshape(-1)
        if len(values) != n:
            # A closed route may append its first point after loading.
            if len(values) == n - 1:
                values = np.append(values, values[0])
            else:
                return np.full(n, 0.5, dtype=np.float64)
        valid = np.isfinite(values) & (values > 0.05)
        if not np.any(valid):
            return np.full(n, 0.5, dtype=np.float64)
        idx = np.arange(n)
        values = np.interp(idx, idx[valid], values[valid])
        return np.clip(values, 0.15, 5.0)

    def reset(self, x: float, z: float, now: Optional[float] = None) -> dict:
        """Initialize the frontier at the closest point to the spawn pose."""
        t = time.monotonic() if now is None else float(now)
        candidate = self._project(float(x), float(z), None)
        if candidate is None:
            raise ValueError("spawn pose is too far from the selected map centerline")
        self.frontier_s = candidate[0]
        self.current_s = candidate[0]
        self.last_push_time = t
        self.last_time = t
        self.frontier_speed_mps = 0.0
        result = self.sample(t)
        result["current_delta_m"] = 0.0
        result["current_projection_valid"] = True
        return result

    def update(self, x: float, z: float, now: Optional[float] = None) -> dict:
        """Update progress; the returned frontier can never retreat."""
        t = time.monotonic() if now is None else float(now)
        if self.frontier_s is None:
            return self.reset(x, z, t)

        old = self.frontier_s
        previous_current = self.current_s if self.current_s is not None else old
        candidate = self._project(float(x), float(z), previous_current)
        dt = max(1e-6, t - (self.last_time if self.last_time is not None else t))
        pushed = 0.0
        current_delta = 0.0
        if candidate is not None:
            # Signed per-step movement is measured against the car's previous
            # route coordinate, not the high-water frontier. This gives reward
            # for recovering ground and a negative delta while moving backward.
            self.current_s = float(candidate[0])
            current_delta = self.current_s - previous_current
            proposed = max(old, self.current_s)
            if proposed - old >= self.min_push_m:
                self.frontier_s = proposed
                pushed = self.frontier_s - old
                self.last_push_time = t
                self.frontier_speed_mps = pushed / dt
            else:
                self.frontier_speed_mps = 0.0
        else:
            self.frontier_speed_mps = 0.0
        self.last_time = t
        result = self.sample(t)
        result["advanced_m"] = pushed
        result["current_delta_m"] = current_delta
        result["current_projection_valid"] = candidate is not None
        return result

    def sample(self, now: Optional[float] = None) -> dict:
        t = time.monotonic() if now is None else float(now)
        if self.frontier_s is None:
            return {"progress_m": 0.0, "line": None, "time_since_push_s": None,
                    "current_progress_m": None, "current_line": None,
                    "current_delta_m": 0.0, "current_projection_valid": False,
                    "speed_mps": 0.0, "advanced_m": 0.0}
        line = self._line_at(self.frontier_s)
        current = self.current_s if self.current_s is not None else self.frontier_s
        current_line = self._line_at(current)
        return {
            "progress_m": float(self.frontier_s),
            "line": [[float(line[0][0]), float(line[0][1])],
                     [float(line[1][0]), float(line[1][1])]],
            "current_progress_m": float(current),
            "current_line": [[float(current_line[0][0]), float(current_line[0][1])],
                             [float(current_line[1][0]), float(current_line[1][1])]],
            "time_since_push_s": max(0.0, t - self.last_push_time)
            if self.last_push_time is not None else None,
            "speed_mps": float(self.frontier_speed_mps),
            "advanced_m": 0.0,
        }

    def project_pose(
        self, x: float, z: float, *, enforce_corridor: bool = True
    ) -> Optional[float]:
        """Return a pose's nearest route coordinate without changing progress.

        ``enforce_corridor=False`` is for recovery controllers that need a
        direction back to the route after the normal progress projection has
        rejected an off-track pose. It still selects the geometrically nearest
        centerline segment and never mutates this tracker's progress state.
        """
        candidate = self._project(
            float(x), float(z), None, enforce_corridor=enforce_corridor
        )
        return None if candidate is None else float(candidate[0])

    def gate_line_at(self, route_s: float):
        """Return the full-width centerline cross-section at route distance ``s``."""
        if not self.closed:
            return None
        line = self._line_at(float(route_s) % self.length_m)
        return [
            [float(line[0][0]), float(line[0][1])],
            [float(line[1][0]), float(line[1][1])],
        ]

    def point_and_tangent_at(self, route_s: float) -> Tuple[np.ndarray, np.ndarray]:
        """Interpolate the route center and forward unit tangent at distance s.

        This exposes the same ordered geometry used for progress projection to
        Layer 3's demonstration driver; it does not add route data to policy
        observations.
        """
        local_s = float(route_s) % self.length_m if self.closed else min(
            max(float(route_s), 0.0), self.length_m
        )
        i = int(np.searchsorted(self._cum, local_s, side="right") - 1)
        i = min(max(i, 0), len(self._lengths) - 1)
        length = self._lengths[i]
        alpha = 0.0 if length <= 1e-8 else (local_s - self._cum[i]) / length
        point = self.points[i] + alpha * (self.points[i + 1] - self.points[i])
        tangent = self._seg[i] / max(length, 1e-8)
        return point.copy(), tangent.copy()

    def _project(
        self, x: float, z: float, frontier: Optional[float], *, enforce_corridor: bool = True
    ):
        pos = np.asarray([x, z], dtype=np.float64)
        laps = (0,)
        if self.closed and frontier is not None:
            base = int(math.floor(frontier / self.length_m))
            laps = (base - 1, base, base + 1)
        valid_seg = self._lengths > 1e-6
        vectors = self._seg[valid_seg]
        starts = self.points[:-1][valid_seg]
        lengths = self._lengths[valid_seg]
        offsets = self._cum[:-1][valid_seg]
        segment_ids = np.flatnonzero(valid_seg)
        t = np.clip(np.sum((pos - starts) * vectors, axis=1) / (lengths * lengths), 0.0, 1.0)
        projected = starts + t[:, None] * vectors
        offset = pos - projected
        lateral = np.linalg.norm(offset, axis=1)
        signed_lateral = (vectors[:, 0] * offset[:, 1] - vectors[:, 1] * offset[:, 0]) / lengths
        right_width = (
            (1.0 - t) * self.widths_right[segment_ids]
            + t * self.widths_right[segment_ids + 1]
        )
        left_width = (
            (1.0 - t) * self.widths_left[segment_ids]
            + t * self.widths_left[segment_ids + 1]
        )
        base_s = offsets + t * lengths

        best = None
        for lap in laps:
            route_s = base_s + (lap * self.length_m if self.closed else 0.0)
            acceptable = np.ones_like(lateral, dtype=bool)
            if enforce_corridor:
                acceptable &= lateral <= self.max_lateral_m
                # Widths are map-derived half-corridor estimates, so keep a small
                # tolerance for rasterization while rejecting off-corridor poses.
                acceptable &= signed_lateral <= left_width + 0.15
                acceptable &= signed_lateral >= -(right_width + 0.15)
            if frontier is not None:
                acceptable &= route_s >= frontier - self.backward_tolerance_m
                acceptable &= route_s <= frontier + self.max_forward_m
            indices = np.flatnonzero(acceptable)
            if len(indices):
                idx = indices[int(np.argmin(lateral[indices]))]
                candidate = (float(lateral[idx]), float(route_s[idx]))
                candidate_is_closer = best is None or candidate[0] < best[0] - 0.02
                if best is not None and frontier is not None:
                    # At a lap seam or self-crossing, multiple ordered route
                    # segments can be equally close geometrically. Prefer the
                    # segment continuous with the previous route coordinate.
                    same_lateral_fit = abs(candidate[0] - best[0]) <= 0.02
                    candidate_is_closer = candidate_is_closer or (
                        same_lateral_fit
                        and abs(candidate[1] - frontier) < abs(best[1] - frontier)
                    )
                if candidate_is_closer:
                    best = candidate
        if best is None:
            return None
        lateral_distance, route_s = best
        return route_s, lateral_distance

    def lateral_distance(self, x: float, z: float) -> Optional[float]:
        """Measure distance from the pose to the locally ordered route center.

        This diagnostic is deliberately allowed outside the drivable corridor:
        training can learn to steer back before the progress projection rejects
        an off-track pose. Route ordering remains constrained around current_s.
        """
        reference = self.current_s if self.current_s is not None else self.frontier_s
        candidate = self._project(
            float(x), float(z), reference, enforce_corridor=False
        )
        return None if candidate is None else float(candidate[1])

    def _line_at(self, route_s: float) -> Tuple[np.ndarray, np.ndarray]:
        local_s = route_s % self.length_m if self.closed else min(route_s, self.length_m)
        i = int(np.searchsorted(self._cum, local_s, side="right") - 1)
        i = min(max(i, 0), len(self._lengths) - 1)
        length = self._lengths[i]
        alpha = 0.0 if length <= 1e-8 else (local_s - self._cum[i]) / length
        a = self.points[i]
        b = self.points[i + 1]
        center = a + alpha * (b - a)
        tangent = (b - a) / max(length, 1e-8)
        left_normal = np.asarray([-tangent[1], tangent[0]])
        wr = self.widths_right[min(i, len(self.widths_right) - 1)]
        wl = self.widths_left[min(i, len(self.widths_left) - 1)]
        right_pt = center - left_normal * wr
        left_pt = center + left_normal * wl
        return right_pt, left_pt


def map_centerline_path(map_id: str, repository_root: Optional[Path] = None) -> Optional[Path]:
    """Resolve a generated map centerline; builtin Unity map has none."""
    if not map_id or map_id == "none":
        return None
    root = repository_root or Path(__file__).resolve().parents[2]
    maps_root = (root / "simulator" / "maps").resolve()
    path = (maps_root / map_id / "occupancy" / "centerline.csv").resolve()
    if not path.is_relative_to(maps_root):
        raise ValueError(f"invalid map id: {map_id!r}")
    if not path.is_file():
        return None
    return path
