"""Layer 2 Gym adapter for official-race evaluation and training.

Policy observations/actions use the same sensor-only transform in both modes.
Training mode may use restricted race counters for reward/episode control and
the documented reset topic; neither capability is enabled for policy runtime.
"""

from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Any, Dict, Optional, Tuple

import gymnasium as gym
import numpy as np

from src.layer1.ros2_racer import OfficialRosTransportError, RacerRos2
from src.layer1.telemetry import TelemetrySnapshot
from .spaces import (
    NegativeThrottleMode,
    SteeringMode,
    make_action_space,
    make_observation_space,
    map_policy_throttle,
    map_throttle_action,
    map_steering_action,
    snapshot_to_obs,
    transform_policy_action,
    _normalize_lidar,
)
from .lidar_odometry import LidarOdometry, acceleration_consistent_lidar_speed
from .route_progress import RouteProgressTracker
from .rewards import RewardConfig, compute_reward_components


class OfficialRaceEnv(gym.Env):
    """Official race flow with optional training-only reset and score reward."""

    metadata = {"render_modes": []}

    def __init__(
        self,
        *,
        racer: Optional[RacerRos2] = None,
        warmup_laps: int = 1,
        race_laps: int = 10,
        timeout_s: float = 180.0,
        frame_timeout_s: float = 5.0,
        steering_action_scale: float = 1.0,
        straight_throttle_gain: float = 1.0,
        straight_throttle_steering_threshold: float = 0.15,
        throttle_mode: str = "bidirectional",
        negative_throttle_mode: NegativeThrottleMode = "allow",
        steering_mode: SteeringMode = "normal",
        vehicle_id: str = "roboracer_1",
        observation_profile: str = "official_sensors",
        training_mode: bool = False,
        training_timeout_s: float = 600.0,
        training_time_cost_per_simulated_second: float = 0.0,
        training_collision_penalty_magnitude: float = 200.0,
        training_collision_reward_percent: float = 0.0,
        training_lap_completion_reward: float = 0.0,
        training_failure_penalty: float = 200.0,
        training_backward_speed_penalty_scale: float = 10.0,
        training_failure_reward_percent: float = 0.0,
        training_frontier_stagnation_s: float = 5.0,
        stop_on_collision: bool = False,
        frontier_path: Optional[Path] = None,
    ) -> None:
        super().__init__()
        if warmup_laps < 0 or race_laps < 1:
            raise ValueError("warmup_laps must be >= 0 and race_laps must be >= 1")
        if not 0.0 <= steering_action_scale <= 1.0:
            raise ValueError("steering_action_scale must be in [0, 1]")
        if not 1.0 <= straight_throttle_gain <= 2.0:
            raise ValueError("straight_throttle_gain must be in [1, 2]")
        if not 0.0 <= straight_throttle_steering_threshold <= 1.0:
            raise ValueError("straight_throttle_steering_threshold must be in [0, 1]")

        self.training_mode = bool(training_mode)
        self._pause_cancel_event = None
        if self.training_mode and (
            float(training_collision_penalty_magnitude) <= 120.0
            or float(training_failure_penalty) <= 120.0
        ):
            raise ValueError(
                "official terminal penalties must exceed the 120-point progress and centerline reward cap"
            )
        if self.training_mode and float(training_lap_completion_reward) != 0.0:
            raise ValueError(
                "official lap learning disables lap bonuses; verified lap completion ends the life successfully"
            )
        if observation_profile not in (
            "official_sensors", "official_sensors_history", "official_sensors_camera"
        ):
            raise ValueError("unsupported official race observation profile")
        self.observation_profile = observation_profile
        self.include_camera = observation_profile == "official_sensors_camera"
        if frame_timeout_s <= 0:
            raise ValueError("frame_timeout_s must be positive")
        # Race setup/metric waits may legitimately be longer. A policy step,
        # however, must never block for the full race-level timeout while the
        # simulator has stopped producing observations.
        self.frame_timeout_s = min(float(frame_timeout_s), float(timeout_s))
        self.training_timeout_s = max(0.0, float(training_timeout_s))
        self.training_failure_penalty = max(0.0, float(training_failure_penalty))
        self.training_backward_speed_penalty_scale = max(0.0, float(training_backward_speed_penalty_scale))
        self.training_failure_reward_percent = max(0.0, float(training_failure_reward_percent))
        self.training_time_cost_per_simulated_second = max(
            0.0, float(training_time_cost_per_simulated_second)
        )
        self.training_collision_penalty_magnitude = max(0.0, float(training_collision_penalty_magnitude))
        self.training_collision_reward_percent = max(0.0, float(training_collision_reward_percent))
        self.training_lap_completion_reward = max(0.0, float(training_lap_completion_reward))
        self.training_frontier_stagnation_s = max(0.0, float(training_frontier_stagnation_s))
        self.stop_on_collision = bool(stop_on_collision)
        self.frontier_path = Path(frontier_path) if frontier_path else None
        self._frontier_spawn_xy: Optional[Tuple[float, float]] = None
        if self.frontier_path is not None:
            metadata_path = self.frontier_path.with_name("official_frontier.json")
            try:
                metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
                spawn = metadata.get("spawn_xy") if isinstance(metadata, dict) else None
                if isinstance(spawn, (list, tuple)) and len(spawn) == 2:
                    self._frontier_spawn_xy = (float(spawn[0]), float(spawn[1]))
            except (OSError, ValueError, TypeError) as exc:
                if self.training_mode:
                    raise ValueError(f"official training frontier metadata is unavailable: {metadata_path}") from exc
            if self.training_mode and self._frontier_spawn_xy is None:
                raise ValueError(f"official training frontier metadata has no valid spawn_xy: {metadata_path}")
        self.route_progress: Optional[RouteProgressTracker] = (
            RouteProgressTracker.from_csv(self.frontier_path)
            if self.training_mode and self.frontier_path is not None else None
        )
        if self.training_mode and self.route_progress is None:
            raise ValueError("official training requires a validated frontier_path")
        self._positive_episode_return = 0.0
        self._episode_frontier_distance_m = 0.0
        self._frontier_last_push_s = 0.0
        self._training_last_motion_s = 0.0
        self._training_last_position: Optional[Tuple[float, float]] = None
        self._last_training_steering = 0.0
        self._centerline_potential = 0.0
        self.racer = racer or RacerRos2(
            vehicle_id=vehicle_id,
            timeout_s=timeout_s,
            frame_timeout_s=self.frame_timeout_s,
            include_race_metrics=True,
            allow_training_reset=self.training_mode,
            require_camera=self.include_camera,
        )
        self._owns_racer = racer is None
        self._observation_builder = OfficialObservationBuilder(
            observation_profile=observation_profile
        )
        self.warmup_laps = int(warmup_laps)
        self.race_laps = int(race_laps)
        # Normalize per-metre reward so the full configured lap target pays at
        # most 100 points. A 200-point terminal penalty therefore keeps every
        # collision/stall life negative while making each safe metre valuable.
        self.training_frontier_reward_cap = 100.0
        self.training_centerline_potential_cap = 20.0
        target_frontier_m = (
            self.route_progress.length_m * self.race_laps
            if self.training_mode and self.route_progress is not None else 0.0
        )
        self.training_frontier_reward_per_m = (
            self.training_frontier_reward_cap / target_frontier_m
            if target_frontier_m > 0 else 0.0
        )
        self.steering_action_scale = float(steering_action_scale)
        self.straight_throttle_gain = float(straight_throttle_gain)
        self.straight_throttle_steering_threshold = float(straight_throttle_steering_threshold)
        # Validate once during environment construction.
        map_throttle_action(0.0, negative_throttle_mode)
        self.negative_throttle_mode = negative_throttle_mode
        map_policy_throttle(0.0, throttle_mode)
        self.throttle_mode = throttle_mode
        map_steering_action(0.0, steering_mode)
        self.steering_mode = steering_mode
        self.action_space = make_action_space()
        self.observation_space = make_observation_space(
            lidar_history_frames=4 if observation_profile == "official_sensors_history" else 1,
            include_camera=self.include_camera,
        )
        self._initial_lap_count = 0
        self._last_lap_count = 0
        self._last_lap_count_update_count: Optional[int] = None
        self._last_lap_count_change_count: Optional[int] = None
        self._last_collision_count = 0
        self._initial_collision_count = 0
        self._race_collision_baseline: Optional[int] = None
        self._warmup_collision_count = 0
        self._race_lap_times_s: list[float] = []
        self._race_lap_timing_missing_count = 0
        self._race_laps_count = 0
        self._warmup_lap_times_s: list[float] = []
        self._warmup_lap_timing_missing_count = 0
        self._episode_steps = 0
        self._training_elapsed_s = 0.0
        self._positive_episode_return = 0.0
        self._episode_frontier_distance_m = 0.0
        self._frontier_last_push_s = 0.0
        self._training_last_motion_s = 0.0
        self._training_last_position = None
        self._last_training_steering = 0.0
        self._last_snap = TelemetrySnapshot(lidar_valid=False)
        self._teacher_info: Dict[str, Any] = {}

    def reset(
        self,
        *,
        seed: Optional[int] = None,
        options: Optional[dict] = None,
    ) -> Tuple[Dict[str, np.ndarray], Dict[str, Any]]:
        super().reset(seed=seed)
        pause_cancel_event = getattr(self, "_pause_cancel_event", None)
        cancel_check = pause_cancel_event.is_set if pause_cancel_event is not None else None
        if self.training_mode:
            reset_for_training = getattr(self.racer, "reset_simulation_for_training", None)
            if not callable(reset_for_training):
                raise RuntimeError("training mode requires a training-reset-capable official racer")
            reset_kwargs = {
                "expected_position": self._frontier_spawn_xy,
                "position_tolerance_m": 0.75,
                "reset_attempts": 3,
            }
            if cancel_check is not None:
                reset_kwargs["cancel_check"] = cancel_check
            snap = reset_for_training(**reset_kwargs)
        else:
            snap = self.racer.wait_until_ready()
        if cancel_check is None:
            metrics = self.racer.wait_for_race_metrics()
        else:
            metrics = self.racer.wait_for_race_metrics(cancel_check=cancel_check)
        self._initial_lap_count = int(metrics.lap_count)
        self._last_lap_count = self._initial_lap_count
        lap_count_update_count = getattr(metrics, "lap_count_update_count", None)
        self._last_lap_count_update_count = (
            int(lap_count_update_count) if lap_count_update_count is not None else None
        )
        lap_count_change_count = getattr(metrics, "lap_count_change_count", None)
        self._last_lap_count_change_count = (
            int(lap_count_change_count) if lap_count_change_count is not None else None
        )
        self._last_collision_count = int(metrics.collision_count)
        self._initial_collision_count = self._last_collision_count
        self._race_collision_baseline = (
            self._last_collision_count if self.warmup_laps == 0 else None
        )
        self._warmup_collision_count = 0
        self._race_lap_times_s = []
        self._race_lap_timing_missing_count = 0
        self._race_laps_count = 0
        self._warmup_lap_times_s = []
        self._warmup_lap_timing_missing_count = 0
        self._episode_steps = 0
        self._training_elapsed_s = 0.0
        self._positive_episode_return = 0.0
        self._episode_frontier_distance_m = 0.0
        self._frontier_last_push_s = 0.0
        self._training_last_motion_s = 0.0
        self._training_last_position = (
            None if metrics.position is None
            else (float(metrics.position[0]), float(metrics.position[1]))
        )
        self._last_training_steering = 0.0
        self._centerline_potential = 0.0
        if self.route_progress is not None:
            position = metrics.position
            if position is None:
                raise RuntimeError("official training reset did not provide restricted IPS position")
            if self._frontier_spawn_xy is not None:
                spawn_error = float(np.linalg.norm(
                    np.asarray(position[:2], dtype=np.float64)
                    - np.asarray(self._frontier_spawn_xy, dtype=np.float64)
                ))
                if spawn_error > 0.75:
                    raise RuntimeError(
                        "official training reset position is not at the configured IPS spawn "
                        f"({spawn_error:.2f} m away); refusing to anchor the route frontier"
                    )
            self.route_progress.reset(float(position[0]), float(position[1]), now=0.0)
            initial_lateral = self.route_progress.lateral_distance(
                float(position[0]), float(position[1])
            )
            if initial_lateral is not None:
                lateral_ratio = min(
                    1.0, initial_lateral / self.route_progress.max_lateral_m
                )
                self._centerline_potential = (
                    -getattr(self, "training_centerline_potential_cap", 20.0)
                    * lateral_ratio * lateral_ratio
                )
        self._last_snap = snap
        initial_obs = self._observation_builder.reset(snap)
        info = self._build_info(snap, metrics, collision_event=False)
        info["watch_speed_mps"] = abs(
            float(self._observation_builder.last_forward_speed_mps)
        )
        if self.route_progress is not None:
            info["current_progress_m"] = float(self.route_progress.current_s or 0.0)
        self._teacher_info = dict(info)
        return initial_obs, info

    def get_current_info(self) -> Dict[str, Any]:
        """Return cached privileged pose for the training-only route teacher."""
        if not self.training_mode:
            raise RuntimeError("privileged teacher state is available only during training")
        return dict(self._teacher_info)

    def request_pause_neutral(self) -> Dict[str, Any]:
        """Release both actuators at a safe training rollout boundary."""
        if not self.training_mode:
            raise RuntimeError("pause-neutral actuation is available only during training")
        return self.racer.request_pause_neutral()

    def set_pause_cancel_event(self, event: Any) -> None:
        """Install the run-local stop sentinel used to bound training reset waits.

        Campaign/smoke mode uses DummyVecEnv with one environment, so the
        process-local threading.Event remains shared with the trainer callback.
        Subprocess vector environments must not pass this threading.Event.
        """
        if not self.training_mode:
            raise RuntimeError("pause cancellation is available only during training")
        if event is not None and not callable(getattr(event, "is_set", None)):
            raise TypeError("pause cancellation sentinel must provide is_set()")
        self._pause_cancel_event = event

    def get_transport_status(self) -> Dict[str, Any]:
        """Expose read-only sensor freshness for supervised pause handshakes."""
        return self.racer.transport_status()

    def step(self, action: np.ndarray):
        throttle, steering = transform_policy_action(
            action,
            throttle_mode=self.throttle_mode,
            negative_throttle_mode=self.negative_throttle_mode,
            steering_mode=self.steering_mode,
            steering_action_scale=self.steering_action_scale,
            straight_throttle_gain=self.straight_throttle_gain,
            straight_throttle_steering_threshold=self.straight_throttle_steering_threshold,
        )

        try:
            snap = self.racer.step(throttle, steering)
        except OfficialRosTransportError as exc:
            raise RuntimeError(
                "OfficialRaceEnv.step cannot continue because the official ROS "
                f"transport did not deliver a fresh observation: {exc}"
            ) from exc
        self._episode_steps += 1
        scan_interval_s = max(0.0, float(self.racer.last_step_duration_s))
        action_interval_s = max(
            0.0, float(getattr(self.racer, "last_control_interval_s", 0.0))
        )
        # Use elapsed time between policy actions. During PPO optimization the
        # official simulator continues to hold the previous actuator command;
        # counting only the final scan interval would undercharge race time and
        # distort the speed estimate at the next decision.
        step_duration_s = action_interval_s if action_interval_s > 0 else scan_interval_s
        metrics = self.racer.race_metrics
        collision_count = int(metrics.collision_count)
        collision_event = collision_count > self._last_collision_count
        current_lap_count = int(metrics.lap_count)
        completed_since_last = max(0, current_lap_count - self._last_lap_count)
        race_lap_events: list[dict[str, Any]] = []
        if completed_since_last:
            current_lap_update_count = getattr(metrics, "lap_count_change_count", None)
            generation_delta = (
                int(current_lap_update_count) - self._last_lap_count_change_count
                if current_lap_update_count is not None
                and self._last_lap_count_change_count is not None else None
            )
            # One latest-value telemetry sample cannot reconstruct several
            # crossings. Do not reuse it across multiple lap-count increments.
            if generation_delta is not None and generation_delta != completed_since_last:
                generation_delta = -1
            for offset in range(completed_since_last):
                relative_laps = self._last_lap_count - self._initial_lap_count + offset + 1
                lap_metrics = metrics
                timing_verified = generation_delta is None
                if generation_delta == 1 and completed_since_last == 1:
                    update_after_count = getattr(
                        metrics, "last_lap_time_update_count_at_lap_count", None
                    )
                    last_time_update_count = getattr(
                        metrics, "last_lap_time_update_count", None
                    )
                    if update_after_count is not None and last_time_update_count is not None:
                        if int(last_time_update_count) <= int(update_after_count):
                            wait_for_lap_time = getattr(
                                self.racer, "wait_for_lap_time_update", None
                            )
                            if callable(wait_for_lap_time):
                                lap_metrics = wait_for_lap_time(
                                    int(update_after_count),
                                    timeout_s=min(self.frame_timeout_s, 0.25),
                                )
                            else:
                                lap_metrics = None
                        timing_verified = (
                            lap_metrics is not None
                            and int(getattr(lap_metrics, "last_lap_time_update_count", -1))
                            > int(update_after_count)
                        )
                    else:
                        timing_verified = False
                elif generation_delta is not None:
                    timing_verified = False

                lap_time = float(
                    getattr(lap_metrics, "last_lap_time", 0.0)
                    if lap_metrics is not None else 0.0
                )
                timing_verified = timing_verified and np.isfinite(lap_time) and lap_time > 0.0
                timing_missing_reason = None
                if not timing_verified:
                    if generation_delta is not None and generation_delta != 1:
                        timing_missing_reason = "multiple_or_unmatched_lap_counter_updates"
                    elif lap_metrics is None:
                        timing_missing_reason = "no_fresh_last_lap_time_update"
                    else:
                        timing_missing_reason = "missing_or_invalid_lap_time"
                if relative_laps <= self.warmup_laps:
                    if timing_verified:
                        self._warmup_lap_times_s.append(lap_time)
                    else:
                        self._warmup_lap_timing_missing_count += 1
                    if relative_laps >= self.warmup_laps:
                        # Warm-up collisions do not count toward the race score.
                        self._race_collision_baseline = collision_count
                        self._warmup_collision_count = max(
                            0, collision_count - self._initial_collision_count
                        )
                else:
                    self._race_laps_count += 1
                    if timing_verified:
                        self._race_lap_times_s.append(lap_time)
                    else:
                        self._race_lap_timing_missing_count += 1
                race_lap_events.append({
                    "official_lap_count": self._last_lap_count + offset + 1,
                    "lap_index": (
                        relative_laps if relative_laps <= self.warmup_laps
                        else self._race_laps_count
                    ),
                    "phase": "warmup" if relative_laps <= self.warmup_laps else "race",
                    "lap_time_s": float(lap_time) if timing_verified else None,
                    "timing_valid": bool(timing_verified),
                    "timing_missing_reason": timing_missing_reason,
                    "timing_update_count": (
                        int(getattr(lap_metrics, "last_lap_time_update_count"))
                        if timing_verified and getattr(lap_metrics, "last_lap_time_update_count", None) is not None
                        else None
                    ),
                })
            self._last_lap_count = current_lap_count
        current_lap_update_count = getattr(metrics, "lap_count_update_count", None)
        if current_lap_update_count is not None:
            self._last_lap_count_update_count = int(current_lap_update_count)
        current_lap_change_count = getattr(metrics, "lap_count_change_count", None)
        if current_lap_change_count is not None:
            self._last_lap_count_change_count = int(current_lap_change_count)

        race_collisions = self._race_collisions(collision_count)
        race_disqualified = race_collisions > 10
        collision_terminated = self.stop_on_collision and collision_event
        terminated = (
            self._race_laps_count >= self.race_laps
            or race_disqualified
            or collision_terminated
        )
        self._last_collision_count = collision_count
        self._last_snap = snap
        info = self._build_info(snap, metrics, collision_event=collision_event)
        info.update({
            "throttle_command": throttle,
            "steering_command": steering,
            "step_duration_s": step_duration_s,
            "official_lap_count": current_lap_count,
            "laps_since_start": max(0, current_lap_count - self._initial_lap_count),
            "warmup_lap_times_s": list(self._warmup_lap_times_s),
            "race_lap_times_s": list(self._race_lap_times_s),
            "race_lap_events": race_lap_events,
            "race_last_lap_time_s": (
                self._race_lap_times_s[-1] if self._race_lap_times_s else None
            ),
            "race_best_lap_time_s": (
                min(self._race_lap_times_s) if self._race_lap_times_s else None
            ),
            "lap_times_s": list(self._race_lap_times_s),
            "race_laps_completed": self._race_laps_count,
            "race_lap_timing_missing_count": self._race_lap_timing_missing_count,
            "race_lap_timing_valid": self._race_lap_timing_missing_count == 0
            and len(self._race_lap_times_s) == self._race_laps_count,
            "warmup_lap_timing_missing_count": self._warmup_lap_timing_missing_count,
            "watch_lap_count": self._race_laps_count,
            "race_collisions": race_collisions,
            "race_collision_baseline": self._race_collision_baseline,
            "warmup_collisions": self._warmup_collision_count,
            "raw_collision_count": collision_count,
            "race_time_s": sum(self._race_lap_times_s),
            "race_complete": self._race_laps_count >= self.race_laps,
            "race_disqualified": race_disqualified,
            "collision_terminated": collision_terminated,
            "lidar_scan_rate_hz": float(snap.lidar_scan_rate),
            "control_interval_s": float(
                getattr(self.racer, "last_control_interval_s", 0.0)
            ),
            "control_interval_source": getattr(self.racer, "control_interval_source", "unknown"),
            "scan_interval_source": getattr(self.racer, "scan_interval_source", "unknown"),
            "control_interval_wall_s": float(
                getattr(self.racer, "last_control_wall_interval_s", 0.0)
            ),
            "command_expiry_count": int(getattr(self.racer, "command_expiry_count", 0)),
            "neutral_fallback_count": int(getattr(self.racer, "neutral_fallback_count", 0)),
        })
        observation = self._observation_builder.observe(
            snap,
            throttle,
            steering,
            elapsed_s=step_duration_s,
        )
        # The encoder-derived ``true_speed`` is useful for diagnostics but can
        # report wheel spin while the body is stopped at a wall. Watch displays
        # the same acceleration-guarded LiDAR estimate used by the policy.
        info["watch_speed_mps"] = abs(
            float(self._observation_builder.last_forward_speed_mps)
        )
        reward = 0.0
        truncated = False
        training_goal_reached = False
        if self.training_mode:
            self._training_elapsed_s += step_duration_s
            route_length_m = max(
                0.0, float(getattr(self.route_progress, "length_m", 0.0))
            )
            target_frontier_m = route_length_m * self.race_laps
            reward_per_m = getattr(
                self, "training_frontier_reward_per_m",
                100.0 / target_frontier_m if target_frontier_m > 0 else 0.0,
            )
            reward_cap = getattr(self, "training_frontier_reward_cap", 100.0)
            position = metrics.position
            # Route projection can stop advancing when a moving car leaves the
            # centerline corridor. That is a bad route estimate, not evidence
            # that the vehicle is stuck. Only terminate for stagnation when
            # both route progress and measured IPS position have stopped.
            if position is not None and len(position) >= 2:
                current_xy = (float(position[0]), float(position[1]))
                previous_xy = getattr(self, "_training_last_position", None)
                if previous_xy is None:
                    self._training_last_position = current_xy
                elif float(np.linalg.norm(np.asarray(current_xy) - np.asarray(previous_xy))) >= 0.02:
                    self._training_last_position = current_xy
                    self._training_last_motion_s = self._training_elapsed_s
            progress = None
            if self.route_progress is not None and position is not None:
                progress = self.route_progress.update(
                    float(position[0]), float(position[1]), now=self._training_elapsed_s
                )
            centerline_shaping = 0.0
            lateral_distance = getattr(self.route_progress, "lateral_distance", None)
            if callable(lateral_distance) and position is not None:
                lateral = lateral_distance(
                    float(position[0]), float(position[1])
                )
                if lateral is not None:
                    lateral_ratio = min(
                        1.0, lateral / self.route_progress.max_lateral_m
                    )
                    next_potential = (
                        -getattr(self, "training_centerline_potential_cap", 20.0)
                        * lateral_ratio * lateral_ratio
                    )
                    centerline_shaping = next_potential - self._centerline_potential
                    self._centerline_potential = next_potential
                    info["centerline_lateral_distance_m"] = float(lateral)
            frontier_advanced = max(0.0, float((progress or {}).get("advanced_m", 0.0)))
            rewardable_frontier_advanced = min(
                frontier_advanced,
                max(0.0, target_frontier_m - self._episode_frontier_distance_m),
            )
            self._episode_frontier_distance_m += frontier_advanced
            if frontier_advanced > 0:
                self._frontier_last_push_s = self._training_elapsed_s
            average_frontier_speed = (
                self._episode_frontier_distance_m / self._training_elapsed_s
                if self._training_elapsed_s > 0 else 0.0
            )
            frontier_stalled = (
                self.training_frontier_stagnation_s > 0
                and self._training_elapsed_s - self._frontier_last_push_s >= self.training_frontier_stagnation_s
                and self._training_elapsed_s - getattr(self, "_training_last_motion_s", 0.0)
                >= self.training_frontier_stagnation_s
            )
            training_goal_reached = bool(
                not collision_event
                and self._race_laps_count >= self.race_laps
                and self._episode_frontier_distance_m >= target_frontier_m * 0.95
            )
            # A clean official lap target ends successfully only when the
            # simulator counter and route frontier agree. Collision and stall
            # still end the life immediately.
            terminated = bool(collision_event or frontier_stalled or training_goal_reached)
            truncated = bool(
                not terminated and self.training_timeout_s > 0
                and self._training_elapsed_s >= self.training_timeout_s
            )
            reason = (
                "collision" if collision_event
                else "training_goal_reached" if training_goal_reached
                else "frontier_stagnation" if frontier_stalled
                else None
            )
            # A frontier stall is a terminal training failure just like the
            # watchdog timeout. Successful target completion has no failure cost.
            episode_failure = bool(
                not training_goal_reached and (frontier_stalled or truncated)
            )
            components = compute_reward_components(
                v_long=float(snap.v_long),
                step_duration_s=step_duration_s,
                frontier_advanced_m=rewardable_frontier_advanced,
                frontier_average_speed_mps=average_frontier_speed,
                frontier_current_speed_mps=(frontier_advanced / step_duration_s if step_duration_s > 0 else 0.0),
                positive_episode_return=self._positive_episode_return,
                collision_event=collision_event,
                episode_failure=episode_failure,
                slip_angle=float(snap.slip_angle),
                prev_steering=self._last_training_steering,
                steering=float(steering),
                cfg=RewardConfig(
                    route_progress_scale=reward_per_m,
                    frontier_pace_target_mps=6.0,
                    # Fixed distance reward and a bounded life budget make
                    # surviving farther better than an early terminal crash.
                    frontier_pace_bonus_strength=0.0,
                    frontier_pace_source="episode_average",
                    time_penalty_per_second=self.training_time_cost_per_simulated_second,
                    backward_speed_penalty_scale=self.training_backward_speed_penalty_scale,
                    backward_speed_deadband_mps=0.1,
                    collision_penalty_magnitude=self.training_collision_penalty_magnitude,
                    collision_reward_percent=self.training_collision_reward_percent,
                    lap_completion_reward=self.training_lap_completion_reward,
                    episode_failure_penalty_magnitude=self.training_failure_penalty,
                    episode_failure_reward_percent=self.training_failure_reward_percent,
                    slip_penalty=0.0,
                    steer_jerk_penalty=0.0,
                    centerline_shaping_delta=centerline_shaping,
                ),
                lap_completion_count=completed_since_last,
            )
            reward = float(components["total"])
            self._positive_episode_return += (
                max(0.0, float(components["route_progress"]))
                + max(0.0, float(components["lap_completion"]))
            )
            self._last_training_steering = float(steering)
            info["training_reward_components"] = components
            info["frontier_progress_m"] = (progress or {}).get("progress_m")
            info["frontier_advanced_m"] = frontier_advanced
            info["frontier_speed_mps"] = average_frontier_speed
            # Keep the names consumed by Layer 4's Watch payload in sync with
            # the official training diagnostics. These are monitoring-only;
            # policy observations remain sensor-only.
            info["frontier_line"] = (progress or {}).get("line")
            info["current_progress_line"] = (progress or {}).get("current_line")
            info["current_progress_m"] = (progress or {}).get("current_progress_m")
            info["signed_route_delta_m"] = (progress or {}).get("current_delta_m")
            info["current_route_speed_mps"] = (
                frontier_advanced / step_duration_s if step_duration_s > 0 else 0.0
            )
            info["route_projection_valid"] = bool(
                progress.get("current_projection_valid") if progress is not None else False
            )
            info["reward_components"] = components
            info["time_since_frontier_push_s"] = (
                max(0.0, self._training_elapsed_s - self._frontier_last_push_s)
                if progress is not None else None
            )
            info["training_positive_frontier_return"] = self._positive_episode_return
            info["training_frontier_distance_m"] = self._episode_frontier_distance_m
            info["training_frontier_reward_per_m"] = reward_per_m
            info["training_frontier_reward_cap"] = reward_cap
            info["training_centerline_shaping"] = centerline_shaping
            info["training_centerline_potential_cap"] = (
                getattr(self, "training_centerline_potential_cap", 20.0)
            )
            info["training_success"] = training_goal_reached
            info["episode_won"] = training_goal_reached
            info["training_frontier_projection_valid"] = (
                bool(progress.get("current_projection_valid")) if progress is not None else False
            )
            info["training_frontier_stagnated"] = frontier_stalled
            info["training_physical_motion_stalled"] = (
                self._training_elapsed_s - getattr(self, "_training_last_motion_s", 0.0)
                >= self.training_frontier_stagnation_s
            )
            info["training_elapsed_s"] = self._training_elapsed_s
            info["termination_reason"] = reason or ("training_watchdog_timeout" if truncated else None)
        race_timing_valid = (
            self._race_lap_timing_missing_count == 0
            and len(self._race_lap_times_s) == self._race_laps_count
        )
        info["race_episode_outcome"] = None
        if terminated or truncated:
            target_frontier_m = (
                float(getattr(self.route_progress, "length_m", 0.0)) * self.race_laps
                if self.training_mode else None
            )
            info["race_episode_outcome"] = {
                "clean_10_lap_episode": bool(
                    self.training_mode
                    and self.race_laps == 10
                    and training_goal_reached
                    and race_timing_valid
                    and race_collisions == 0
                ),
                "episode_won": bool(info.get("episode_won", False)),
                "termination_reason": info.get("termination_reason"),
                "race_laps_completed": self._race_laps_count,
                "race_laps_required": self.race_laps,
                "race_lap_times_s": list(self._race_lap_times_s),
                "race_lap_timing_valid": race_timing_valid,
                "race_lap_timing_missing_count": self._race_lap_timing_missing_count,
                "race_collisions": race_collisions,
                "raw_collision_count": collision_count,
                "race_time_s": float(sum(self._race_lap_times_s)),
                "route_frontier_distance_m": float(self._episode_frontier_distance_m),
                "route_frontier_target_m": target_frontier_m,
            }
        # The official scoring harness is deterministic evaluation, not PPO
        # training; scores come from official lap timing and collision counts.
        self._teacher_info = dict(info)
        return observation, reward, terminated, truncated, info

    def _race_collisions(self, current_count: int) -> int:
        baseline = self._race_collision_baseline
        if baseline is None:
            return 0
        return max(0, int(current_count) - int(baseline))

    def _build_info(
        self,
        snap: TelemetrySnapshot,
        metrics: Any,
        *,
        collision_event: bool,
    ) -> Dict[str, Any]:
        transport_status = getattr(self.racer, "transport_status", None)
        transport_diagnostics = transport_status() if callable(transport_status) else {}
        return {
            # Restricted state is monitoring-only: it can support training
            # reward/evaluation but is intentionally excluded from observation.
            "race_position": metrics.position,
            # Watch may render the restricted training/evaluation position;
            # this field is not read by the policy observation builder.
            "position": metrics.position,
            "position_age_s": (
                max(0.0, time.monotonic() - float(getattr(metrics, "position_received_at", 0.0)))
                if getattr(metrics, "position_received_at", 0.0) else None
            ),
            "yaw": float(snap.heading_yaw),
            "v_long": float(snap.v_long),
            "true_speed": float(snap.true_speed),
            "throttle": float(snap.throttle),
            "steering": float(snap.steering),
            "collision": False,
            "collision_event": bool(collision_event),
            "collision_count": int(metrics.collision_count),
            "lap_count": int(metrics.lap_count),
            "lap_time_s": float(metrics.lap_time),
            "last_lap_time_s": float(metrics.last_lap_time),
            "best_lap_time_s": float(metrics.best_lap_time),
            "official_race": True,
            "lap_supported": True,
            "lidar_range_min": float(snap.lidar_range_min),
            "lidar_range_max": float(snap.lidar_range_max),
            "lidar_beams": int(snap.lidar_ranges.size),
            # Monitoring-only Layer 1 sensor values. They let Watch show the
            # measurements the teacher actually used without exposing pose or
            # route labels to the student policy.
            "lidar_left_clearance_m": self._lidar_sector_clearance(snap, 70.0, 110.0),
            "lidar_front_clearance_m": self._lidar_sector_clearance(snap, -12.0, 12.0),
            "lidar_right_clearance_m": self._lidar_sector_clearance(snap, -110.0, -70.0),
            # Read-only monotonic timing evidence for command-expiry diagnosis.
            # It contains no additional policy observation or route target.
            "command_expiry_diagnostic": transport_diagnostics.get(
                "command_expiry_diagnostic"
            ),
            "neutral_fallback_count": int(transport_diagnostics.get("neutral_fallback_count", 0)),
            "neutral_fallback_diagnostic": transport_diagnostics.get(
                "neutral_fallback_diagnostic"
            ),
        }

    @staticmethod
    def _lidar_sector_clearance(
        snap: TelemetrySnapshot, angle_low_deg: float, angle_high_deg: float
    ) -> Optional[float]:
        values = np.asarray(snap.lidar_ranges, dtype=np.float32).reshape(-1)
        if values.size != 1081 or np.isnan(values).any() or np.isneginf(values).any():
            return None
        values = np.where(np.isposinf(values), float(snap.lidar_range_max), values)
        values = np.clip(values, float(snap.lidar_range_min), float(snap.lidar_range_max))
        # Layer 1 canonicalizes an increasing ROS scan by reversing it, so
        # beam index zero is +135 degrees. Positive angles point to vehicle
        # left in the official AutoDRIVE frame.
        angles = np.linspace(135.0, -135.0, values.size)
        selected = values[(angles >= angle_low_deg) & (angles <= angle_high_deg)]
        if not selected.size:
            return None
        return float(np.percentile(selected, 8.0))

    def close(self) -> None:
        if self._owns_racer:
            self.racer.kill()


class OfficialObservationBuilder:
    """Canonical sensor-only observation transform for official training and race.

    Keep this stateful transform shared: a small difference in speed filtering,
    scan history, or update ordering changes the policy's effective dynamics.
    """

    def __init__(self, *, observation_profile: str = "official_sensors") -> None:
        if observation_profile not in (
            "official_sensors", "official_sensors_history", "official_sensors_camera"
        ):
            raise ValueError("unsupported official race observation profile")
        self.observation_profile = observation_profile
        self.include_camera = observation_profile == "official_sensors_camera"
        self._lidar_history: list[np.ndarray] = []
        self._lidar_speed_estimator = LidarOdometry()
        self._observation_heading_yaw: Optional[float] = None
        self._last_lidar_forward_speed_mps = 0.0
        self.last_forward_speed_mps = 0.0

    def reset(self, snap: TelemetrySnapshot) -> Dict[str, np.ndarray]:
        self._lidar_history = []
        self._lidar_speed_estimator.reset()
        self._observation_heading_yaw = float(snap.heading_yaw)
        self._last_lidar_forward_speed_mps = 0.0
        self.last_forward_speed_mps = 0.0
        if self.observation_profile == "official_sensors_history":
            scan = _normalize_lidar(snap)
            self._lidar_history = [scan.copy(), scan.copy(), scan.copy()]
        history = (
            self._lidar_history
            if self.observation_profile == "official_sensors_history"
            else None
        )
        return snapshot_to_obs(
            snap,
            0.0,
            0.0,
            forward_speed_mps=0.0,
            lateral_speed_mps=0.0,
            lidar_history=history,
            include_camera=self.include_camera,
        )

    def observe(
        self,
        snap: TelemetrySnapshot,
        prev_throttle: float,
        prev_steering: float,
        *,
        elapsed_s: float,
    ) -> Dict[str, np.ndarray]:
        previous_yaw = self._observation_heading_yaw
        yaw_delta = None
        if previous_yaw is not None:
            yaw_delta = float(
                np.arctan2(
                    np.sin(float(snap.heading_yaw) - previous_yaw),
                    np.cos(float(snap.heading_yaw) - previous_yaw),
                )
            )
        motion = self._lidar_speed_estimator.update(
            snap.lidar_ranges,
            elapsed_s,
            yaw_delta_rad=yaw_delta,
        )
        self._observation_heading_yaw = float(snap.heading_yaw)
        forward_speed = 0.0
        if motion.valid:
            forward_speed = acceleration_consistent_lidar_speed(
                motion.forward_m,
                self._last_lidar_forward_speed_mps,
                float(snap.linear_acceleration[0]),
                elapsed_s,
            )
        self._last_lidar_forward_speed_mps = forward_speed
        self.last_forward_speed_mps = forward_speed
        history = (
            self._lidar_history
            if self.observation_profile == "official_sensors_history"
            else None
        )
        observation = snapshot_to_obs(
            snap,
            prev_throttle,
            prev_steering,
            forward_speed_mps=forward_speed,
            lateral_speed_mps=0.0,
            lidar_history=history,
            include_camera=self.include_camera,
        )
        if history is not None:
            self._lidar_history.append(_normalize_lidar(snap))
            self._lidar_history = self._lidar_history[-3:]
        return observation
