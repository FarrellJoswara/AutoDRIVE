# Layer 3 — Learning to drive (plan / README)

**Status:** Implemented (v1). Build plan / checklist: [`LAYER3.md`](../../LAYER3.md).

Layer 3 is the **brain trainer**: it uses Layer 2’s Gym env and teaches a neural net to pick throttle + steering.

---

## Plain English: what problem are we solving?

Every official camera-enabled training step, the car gives us three inputs:

1. **LiDAR** — 1081 distance readings in a fan around the car (“how far is stuff in each direction?”).
2. **State** — 9 normalized sensor/control values (body speeds, yaw rate, acceleration, actuator feedback, and previous commands).
3. **Front camera** — official RGB frames, resized to 160×90.

We need the computer to turn that into:

```text
[throttle, steering]
```

A **neural net** does that. While **training**, we also keep score (reward from Layer 2). If the car went forward, that’s usually good. The trainer (PPO) nudges the net so “good” actions happen more often.

---

## “LiDAR CNN + camera CNN + state MLP, then fuse” — what that actually means

Think of the net as a **three-input gadget** that combines range, vision, and vehicle state before choosing the pedals.

### Input A — LiDAR (1081 numbers in a row)

Imagine standing in a circle and measuring distance every fraction of a degree. That’s a **line of 1081 numbers**, left → right around the car, including both edges of the 270° scan.

A **1D-CNN** is a small sliding window that looks at **nearby beams together** (e.g. “these 5 beams next to each other look like a wall / a gap”). It slides along the strip and builds a shorter summary that means something like “shape of the free space.”

Why not dump all 1081 into a normal dense net? You *can*, but then every beam is mixed with every other beam with no built-in idea that beam 50 is next to beam 51. The CNN is a cheat sheet: “neighbors matter.”

### Input B — State (9 numbers)

Speed, sideways slip, last controls, etc. There’s no “strip of space” here — just a small bag of facts. A plain **MLP** (stack of fully connected layers: numbers in → mix → numbers out) is enough.

### “Fuse”

We now have:

- a summary vector from the LiDAR CNN  
- a visual summary from the camera CNN
- a summary vector from the state MLP  

**Fuse** = glue them into **one longer list of numbers** (e.g. 256 floats). That list is the car’s situation in a form the rest of the net likes.

```text
  lidar[1081]       ──▶ 1D-CNN ──▶ summary_A ─┐
  camera[90x160x3]  ──▶ 2D-CNN ──▶ summary_B ──┼─▶ glue ──▶ one feature vector (e.g. 256)
  state[9]          ──▶ MLP    ──▶ summary_C ──┘
                                              │
                                              ▼
                                    “what should I do?” heads
                                    (throttle + steering)
```

That glue module is what we call the **feature extractor** (`extractors.py`).

---

## Is Layer 3 “just the extractor”?

**No.**

| Piece | Where | What it does |
|-------|--------|--------------|
| Feature extractor | `src/layer3/extractors.py` | LiDAR CNN + camera CNN + state MLP → one feature vector |
| Env / VecEnv factory | `src/layer3/envs.py` | 1 env, or **N envs via SubprocVecEnv** |
| Demonstration driver | `src/layer3/expert.py` | Optional map-aware teacher for action labels; disabled by default |
| Behavior cloning | `src/layer3/behavior_cloning.py` | Warm-start PPO actor from official camera/LiDAR/state demonstrations |
| **Training** | `src/layer3/train.py` | PPO training, deterministic evaluation, best-checkpoint selection, evaluation plateau and bounded exploration |
| **Evaluation** | `src/layer3/evaluate.py` | Fixed simulated-time deterministic frontier, pace, crash, stall and lap diagnostics |
| **Playback** | `src/layer3/play.py` | Load `.zip`, drive — **no learning** (always 1 env) |
| Thin CLI | `scripts/demo.py train` / `play` | Flags → calls into `layer3` |
| Extractor unit test | `scripts/test_layer3_extractor.py` | Fake tensors; no Unity |

PPO’s update math is inside **Stable-Baselines3**. We wire envs + net + `learn()`.

### Many sims at once

Faster training = **N** cars in **N processes**, still **one** brain:

```text
Env0 @ port 4567 ─┐
Env1 @ port 4568 ─┼─▶ SubprocVecEnv ─▶ PPO updates ONE net
Env2 @ port 4569 ─┘
```

Implemented in `envs.py` / `train.py`. Full detail: [`LAYER3.md` §5](../../LAYER3.md).

---

## What training actually does (no jargon)

1. Start one or more Gym envs (each talks to its own sim via Layers 1–2).
2. New Mission Control official runs first use a route-aware teacher in the selected official simulator environments to label camera/LiDAR/state observations with throttle and steering. Privileged route pose is read only to choose teacher actions; it is not saved in the demonstration archive or passed to PPO. Resumed runs skip this stage.
3. If teacher labels were collected, behavior cloning can initialize the PPO actor from them. Otherwise PPO starts from its own initialization (or the checkpoint selected with Resume).
4. A lap crossing never ends an episode. Cars continue until a collision, stalled frontier, or configured safety termination; lap counts and times remain measurements.
5. A separate simulator evaluates an immutable policy snapshot in the background for the configured number of attempts, while the training simulators continue collecting experience. Each attempt ends on collision, frontier stall, or ten completed laps. The median selected score drives checkpoint selection, exploration changes, and plateau stopping; per-attempt scores, the mean, and the best attempt are retained for inspection. If an evaluation batch is still running at the next interval, one request for the latest policy is queued; snapshots never overlap. Attempts currently repeat the configured map spawn, so they measure simulator consistency rather than generalization across spawn conditions.
6. PPO exploration standard deviation is clamped to settings-defined bounds, reduced after evaluation improvements, and raised modestly after repeated stale evaluations. The Unity pause callback resumes physics when training exits.
7. `python -m src.layer3.evaluate --model logs/rl/<run>/final_model.zip --map-id porto` runs the same failure-or-ten-lap evaluation outside training.

Playback skips 3–4: load zip → only look → act (single car).

### Official simulator behavior cloning → PPO

The Mission Control **Train** page exposes the route-teacher stage and PPO as one official workflow. A new run collects the configured number of teacher steps from each official simulator environment, fits the shared PPO actor to those actions, then starts PPO on the same environment pool. The saved demonstration archive contains only `lidar`, `camera` (when enabled), `state`, and `actions`; route pose stays runtime-only. `behavior_cloning_summary.json` records the held-out imitation loss and collection counts. Resumed checkpoints skip cloning.

To assess cloning before PPO changes the policy, select **Save BC policy and stop** on Train. Mission Control collects the official examples, fits the actor, saves `behavior_cloned_policy.zip` with the run's observation/action metadata, and exits before PPO rollout. On Replay, select that checkpoint and start the official evaluation. It runs the same policy deterministically, without teacher actions or learning updates, through one warm-up lap and ten scored laps in three fresh official simulator attempts. Evaluation results are diagnostic; only a valid official race result can promote the shared best model.

Camera pixels are `uint8` RGB and are divided by 255 once inside the custom vision extractor. Stable-Baselines3 image normalization is disabled for these custom policies to prevent a second division. The official checkpoint loader also repairs that setting when it loads older camera checkpoints. This corrects inference input scaling; it does not establish that legacy model weights learned from the corrected scale.

### Privileged PPO to sensor-only transfer experiment

`python scripts/distill_policy.py --teacher <simulator-profile-checkpoint.zip>
--out logs/rl/<new-trial>` collects the current official-sensor observation
alongside deterministic actions from a simulator-profile PPO teacher, then
behavior-clones a fresh actor. Layer 2 exposes the teacher observation only to
this explicit Layer 3 collector. The compressed dataset contains only LiDAR,
the official sensor state vector, and action labels. It contains no map pose,
route progress, collision count, or teacher observation. The resulting
`sensor_student.zip` can be resumed with ordinary PPO using
`--observation-profile official_sensors`; distillation itself does not change
the default training flow or competition inference path. This is a transfer
hypothesis, not a competition result, and it requires a successful like-for-like
evaluation before promotion. A later DAgger round can add
`--student-policy <sensor_student.zip>` and
`--previous-dataset <sensor_demonstrations.npz>`: the student then drives while
the teacher labels the states it actually visits. Cloning validation holds out
the final chronological segment instead of randomly mixing adjacent frames.

---

## Layer 3 files

```text
src/layer3/
  __init__.py
  extractors.py    # CNN + MLP + fuse
  envs.py          # make_env / make_vec_env (Dummy vs Subproc)
  expert.py        # centerline teacher for action labels
  behavior_cloning.py # demonstrations + actor warm start
  train.py         # curriculum + PPO + checkpoints
  evaluate.py      # repeatable policy evaluation
  play.py          # load + drive
  README.md        # this file

scripts/demo.py                  # thin CLI → layer3.train / layer3.play
scripts/test_layer3_extractor.py
```

---

## How to use (after it’s built)

```bash
# teach — smoke (1 env)
python scripts/demo.py train --n-envs 1 --timesteps 100000 --out logs/rl/run1

# teach — parallel sims
python scripts/demo.py train --n-envs 2 --timesteps 100000 --out logs/rl/run2

# watch / eval (always 1 env, no learning)
python scripts/demo.py play --model logs/rl/run2/final_model.zip --steps 2000
```

Reward math stays in Layer 2 (`src/layer2/rewards.py`). Layer 3 should not reinvent scoring.

---

## Related

- Root plan + checklist: [`LAYER3.md`](../../LAYER3.md)  
- Layer 2 env/rewards: [`../layer2/README.md`](../layer2/README.md)  
- Layer 1 driver: [`../layer1/README.md`](../layer1/README.md)
