"""Layer 1 unit + mock Socket.IO tests (no Unity binary required)."""

from __future__ import annotations

import math
import os
import sys
import tempfile
import threading
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

import numpy as np
import pytest
import socketio

from src.layer1.telemetry import TelemetrySnapshot, TrajectoryLogger
from src.layer1.track import RaceTrack


# ---------------------------------------------------------------------------
# Telemetry / geometry
# ---------------------------------------------------------------------------


def test_telemetry_snapshot_parsing():
    """Parse a raw AutoDRIVE Bridge packet into TelemetrySnapshot."""
    # Real Socket capture at Porto spawn. Bridge position order is (z,-x,y);
    # quaternion rotation is around Bridge Z and becomes Unity Y yaw.
    raw_packet = {
        "V1 Position": "-1.3900 -7.5350 0.0861",
        "V1 Orientation Quaternion": "0.0103 0.0103 -0.7094 0.7047",
        "V1 Orientation Euler Angles": "0.0021 0.0291 4.7058",
        "V1 Linear Velocity": [3.0, 0.0, 4.0],
        "V1 Angular Velocity": [0.0, 0.1, 0.55],
        "V1 Linear Acceleration": [0.0, 0.0, 9.80665],
        "V1 Encoder Angles": [12.5, 12.8],
        "V1 Encoder Ticks": [100, 102],
        "V1 Lidar Scan": [1.5] * 1080,
        "V1 LIDAR Scan Rate": 40.0,
        "V1 Throttle": 0.8,
        "V1 Steering": -0.15,
        "V1 Lap Count": 2,
        "V1 Lap Time": 14.25,
        "V1 Collisions": 0,
    }

    snap = TelemetrySnapshot.from_raw_dict(raw_packet, step_id=42)

    assert snap.step_id == 42
    assert snap.position == pytest.approx((7.535, 0.0861, -1.39))
    assert pytest.approx(snap.true_speed, 0.001) == 5.0
    assert pytest.approx(snap.v_long, 0.001) == 3.0
    assert pytest.approx(snap.v_lat, 0.001) == 0.0
    assert pytest.approx(snap.encoder_left, 0.001) == 12.5
    assert pytest.approx(snap.encoder_right, 0.001) == 12.8
    assert pytest.approx(snap.encoder_ticks_left, 0.001) == 100.0
    assert pytest.approx(snap.encoder_ticks_right, 0.001) == 102.0
    assert len(snap.lidar_ranges) == 1080
    assert snap.lidar_valid
    assert snap.lidar_ranges[0] == 1.5
    assert snap.lidar_scan_rate == 40.0
    assert snap.throttle == 0.8
    assert snap.steering == -0.15
    assert snap.lap_count == 2
    assert not snap.collision
    assert snap.collision_count == 0
    assert pytest.approx(snap.heading_yaw, 0.01) == 1.577


def test_orientation_euler_and_collision_keys():
    """Euler Angles fallback + V1 Collisions primary key."""
    raw = {
        "V1 Position": [0.0, 0.0, 0.0],
        "V1 Orientation Euler Angles": f"0.0 0.0 {math.pi / 4:.6f}",
        "V1 Linear Velocity": [0.0, 0.0, 0.0],
        "V1 Collisions": 3,
        "V1 LIDAR Scan Rate": 20.0,
    }
    snap = TelemetrySnapshot.from_raw_dict(raw, step_id=1)
    assert pytest.approx(snap.heading_yaw, 0.01) == -math.pi / 4
    assert snap.collision
    assert snap.collision_count == 3
    assert snap.lidar_scan_rate == 20.0


def test_identity_orientation_is_valid_and_body_velocity_never_infers_yaw():
    """A valid identity quaternion means yaw=0, even while moving in reverse."""
    q_identity = {
        "V1 Position": [0.0, 0.0, 0.0],
        "V1 Orientation Quaternion": [0.0, 0.0, 0.0, 1.0],
        "V1 Linear Velocity": [-3.0, 0.0, 0.0],
    }
    snap_identity = TelemetrySnapshot.from_raw_dict(q_identity, step_id=1)
    assert pytest.approx(snap_identity.heading_yaw, 1e-6) == 0.0
    assert pytest.approx(snap_identity.v_long, 1e-6) == -3.0

    # Euler yaw=0 with sideways velocity must keep IMU yaw (not velocity).
    euler_zero = {
        "V1 Position": [0.0, 0.0, 0.0],
        "V1 Orientation Euler Angles": "0.0 0.0 0.0",
        "V1 Linear Velocity": [5.0, 0.0, 0.0],
    }
    snap_keep = TelemetrySnapshot.from_raw_dict(euler_zero, step_id=2)
    assert pytest.approx(snap_keep.heading_yaw, 1e-6) == 0.0


def test_yaw_rate_converts_bridge_z_to_unity_y():
    """Bridge +Z angular rate reverses into the Unity +Y yaw convention."""
    from src.layer2.spaces import snapshot_to_obs

    snap = TelemetrySnapshot(
        angular_velocity=(0.1, 0.2, 0.75),
        v_long=1.0,
        v_lat=0.0,
        slip_angle=0.0,
        linear_acceleration=(0.0, 0.0, 0.0),
    )
    obs = snapshot_to_obs(snap, prev_throttle=0.0, prev_steering=0.0)
    assert pytest.approx(float(obs["state"][2]), 1e-6) == -0.075


def test_body_kinematics_are_not_rotated_again_and_observation_is_scaled():
    from src.layer2.spaces import make_observation_space, snapshot_to_obs

    raw = {
        "V1 Orientation Euler Angles": f"0.0 0.0 {math.pi / 2:.8f}",
        "V1 Linear Velocity": [11.44, -2.288, 0.0],
        "V1 Linear Acceleration": [4.903325, -4.903325, 0.0],
        "V1 Angular Velocity": [0.0, 0.0, 7.5],
        "V1 Throttle": 0.4,
        "V1 Steering": 0.18326,
        "V1 LIDAR Range Array": [10.0] * 1081,
    }
    snap = TelemetrySnapshot.from_raw_dict(raw)
    assert pytest.approx(snap.heading_yaw, abs=1e-5) == -math.pi / 2
    assert snap.v_long == pytest.approx(11.44)
    assert snap.v_lat == pytest.approx(2.288)
    assert snap.lateral_g == pytest.approx(0.5)

    obs = snapshot_to_obs(snap, prev_throttle=0.2, prev_steering=-0.4)
    assert obs["state"].shape == (9,)
    assert obs["state"] == pytest.approx(
        [0.5, 0.1, -0.75, 0.5, 0.5, 0.4, 0.35, 0.2, -0.4], abs=1e-5
    )
    assert make_observation_space().contains(obs)


def test_lidar_keeps_all_1081_rays_and_maps_positive_infinity_to_no_hit():
    from src.layer2.spaces import snapshot_to_obs

    raw = np.full(1081, 5.0, dtype=np.float32)
    raw[0], raw[540], raw[700], raw[-1] = 0.06, np.inf, 0.03, 10.0
    snap = TelemetrySnapshot(lidar_ranges=raw)
    lidar = snapshot_to_obs(snap, 0.0, 0.0)["lidar"]
    assert lidar.shape == (1081,)
    assert lidar[0] == pytest.approx(0.0)
    assert lidar[540] == pytest.approx(1.0)
    assert lidar[700] == pytest.approx(1.0)
    assert lidar[-1] == pytest.approx(1.0)


def test_documented_1080_lidar_scan_is_resampled_to_canonical_shape():
    from src.layer2.spaces import snapshot_to_obs

    snap = TelemetrySnapshot(lidar_ranges=np.linspace(0.06, 10.0, 1080, dtype=np.float32))
    lidar = snapshot_to_obs(snap, 0.0, 0.0)["lidar"]
    assert lidar.shape == (1081,)
    assert lidar[0] == pytest.approx(0.0)
    assert lidar[-1] == pytest.approx(1.0)


@pytest.mark.parametrize("bad_ranges", [
    np.full(1081, np.nan, dtype=np.float32),
    np.full(1081, -np.inf, dtype=np.float32),
    np.zeros(1081, dtype=np.float32),
    np.full(1079, 1.0, dtype=np.float32),
])
def test_invalid_lidar_fails_clearly_instead_of_becoming_fake_obstacles(bad_ranges):
    from src.layer2.spaces import snapshot_to_obs

    with pytest.raises(ValueError, match="LiDAR"):
        snapshot_to_obs(TelemetrySnapshot(lidar_ranges=bad_ranges), 0.0, 0.0)


def test_missing_or_corrupt_lidar_is_marked_invalid_by_parser():
    missing = TelemetrySnapshot.from_raw_dict({"V1 LIDAR Range Array": None})
    corrupt = TelemetrySnapshot.from_raw_dict({"V1 LIDAR Range Array": "not-a-gzip-packet"})
    assert not missing.lidar_valid
    assert not corrupt.lidar_valid
    assert missing.lidar_ranges.size == 0


def test_bridge_lidar_scan_is_canonicalized_to_ccw_order():
    raw = {
        "V1 Position": [0.0, 0.0, 0.0],
        "V1 LIDAR Range Array": [0.1, 0.2, 0.3, 0.4],
    }
    snap = TelemetrySnapshot.from_raw_dict(raw, step_id=1)
    assert snap.lidar_ranges.tolist() == pytest.approx([0.4, 0.3, 0.2, 0.1])


def test_trajectory_logger_csv_export():
    """Buffer snapshots and export a CSV with header + rows."""
    logger = TrajectoryLogger()
    snap1 = TelemetrySnapshot(
        step_id=1,
        position=(1.0, 0.0, 2.0),
        orientation_quat=(0.0, 0.0, 0.0, 1.0),
        true_speed=3.5,
        throttle=0.5,
        steering=0.0,
    )
    snap2 = TelemetrySnapshot(
        step_id=2,
        position=(2.0, 0.0, 4.0),
        orientation_quat=(0.0, 0.0, 0.0, 1.0),
        true_speed=4.0,
        throttle=0.7,
        steering=0.1,
    )
    logger.log(snap1)
    logger.log(snap2)
    assert len(logger) == 2

    with tempfile.TemporaryDirectory() as tmp_dir:
        csv_path = os.path.join(tmp_dir, "test_log.csv")
        saved_file = logger.save_to_csv(csv_path)
        assert os.path.exists(saved_file)
        with open(saved_file, "r") as f:
            lines = f.readlines()
            assert len(lines) == 3
            assert "step_id,timestamp,pos_x" in lines[0]


def test_racetrack_geometry_and_checkpoints():
    """Frenet progress and gate tracking without needing a live Unity client."""
    waypoints = np.array(
        [
            [0.0, 0.0],
            [10.0, 0.0],
            [20.0, 0.0],
            [20.0, 10.0],
            [10.0, 10.0],
            [0.0, 10.0],
            [0.0, 0.0],
        ]
    )
    track = RaceTrack(
        num_racers=1,
        base_port=19999,
        num_gates=4,
        waypoints=waypoints,
        auto_launch=False,
    )
    try:
        assert track.track_length > 0.0
        assert len(track.gate_locations) == 4
        s, d = track.get_frenet_progress(0.0, 0.0)
        assert pytest.approx(s, 0.1) == 0.0
        assert pytest.approx(d, 0.1) == 0.0
        passed, _lap = track.update_checkpoints(0, 0.1)
        assert passed
    finally:
        track.kill_all()


# ---------------------------------------------------------------------------
# Mock Socket.IO lockstep (1 car)
# ---------------------------------------------------------------------------


def test_lockstep_stepping_and_kill():
    """One mock Unity client: step, command emit, CSV export, kill."""
    port = 18888
    track = RaceTrack(num_racers=1, base_port=port, auto_launch=False)

    client = socketio.Client()
    received_commands = []
    running = True

    @client.on("Bridge")
    def on_bridge_reply(data):
        received_commands.append(data)

    try:
        client.connect(f"http://127.0.0.1:{port}")
        time.sleep(0.2)
        assert client.connected

        def unity_simulation_loop():
            step_num = 1
            while running and client.connected:
                fake_bridge_data = {
                    "V1 Position": [step_num * 0.1, 0.0, step_num * 0.5],
                    "V1 Orientation Quaternion": [0.0, 0.0, 0.0, 1.0],
                    "V1 Linear Velocity": [0.0, 0.0, 10.0],
                    "V1 Angular Velocity": [0.0, 0.0, 0.0],
                    "V1 Linear Acceleration": [0.0, 0.0, 1.0],
                    "V1 Encoder Angles": [step_num * 1.5, step_num * 1.5],
                    "V1 Encoder Ticks": [step_num * 10, step_num * 10],
                    "V1 Lidar Scan": [5.0] * 1080,
                    "V1 LIDAR Scan Rate": 40.0,
                    "V1 Throttle": 0.5,
                    "V1 Steering": 0.0,
                    "V1 Lap Count": 0,
                    "V1 Lap Time": step_num * 0.025,
                    "V1 Collisions": 0,
                }
                try:
                    client.emit("Bridge", fake_bridge_data)
                    step_num += 1
                except Exception:
                    break
                time.sleep(0.01)

        threading.Thread(target=unity_simulation_loop, daemon=True).start()
        time.sleep(0.05)

        snap = track.step_single(0, throttle=0.85, steering=-0.3)
        assert snap.position[2] > 0.0
        assert snap.true_speed == 10.0

        snap2 = track.step_single(0, throttle=0.5, steering=0.1)
        assert snap2.step_id >= 2

        deadline = time.time() + 2.0
        while time.time() < deadline and not received_commands:
            time.sleep(0.05)
        assert len(received_commands) >= 1
        matching_commands = [
            c
            for c in received_commands
            if c is not None and abs(float(c.get("V1 Throttle", 0.0)) - 0.85) < 0.05
        ]
        assert len(matching_commands) > 0
        assert "V1 Reset" in matching_commands[0]

        racer = track.racers[0]
        assert racer.step_counter >= 2
        assert racer.step_latency_ms >= 0.0

        with tempfile.TemporaryDirectory() as tmp_dir:
            exported = track.save_all_trajectories(tmp_dir)
            assert 0 in exported
            with open(exported[0], "r") as f:
                assert len(f.readlines()) >= 2

        killed = track.kill_racer(0)
        assert killed
        assert not track.racers[0].is_alive
    finally:
        running = False
        try:
            if client.connected:
                client.disconnect()
        except Exception:
            pass
        try:
            track.kill_all()
        except Exception:
            pass


# ---------------------------------------------------------------------------
# Mock Socket.IO lockstep (2 cars)
# ---------------------------------------------------------------------------


def test_two_instances_lockstep_drive():
    """Two mock Unity clients stepped together via RaceTrack.step_all."""
    base_port = 24567
    track = RaceTrack(num_racers=2, base_port=base_port, auto_launch=False)

    assert len(track.racers) == 2
    assert track.racers[0].port == 24567
    assert track.racers[1].port == 24568

    client0 = socketio.Client()
    client1 = socketio.Client()
    running = True
    received_0 = []
    received_1 = []

    @client0.on("Bridge")
    def on_bridge_0(data):
        received_0.append(data)

    @client1.on("Bridge")
    def on_bridge_1(data):
        received_1.append(data)

    try:
        client0.connect(f"http://127.0.0.1:{base_port}")
        client1.connect(f"http://127.0.0.1:{base_port + 1}")
        assert client0.connected
        assert client1.connected

        def sim_loop(client, car_idx):
            step = 1
            while running and client.connected:
                data = {
                    # Bridge wire order is (z, -x, y); want Unity (x=car*2, y=0, z=step*0.5)
                    "V1 Position": f"{step * 0.5} {-car_idx * 2.0} 0.0",
                    "V1 Orientation Quaternion": "0.0 0.0 0.0 1.0",
                    "V1 Linear Velocity": "0.0 0.0 8.5",
                    "V1 Angular Velocity": "0.0 0.0 0.0",
                    "V1 Linear Acceleration": "0.0 0.0 0.5",
                    "V1 Encoder Angles": f"{step * 1.2} {step * 1.2}",
                    "V1 Encoder Ticks": f"{step * 8} {step * 8}",
                    "V1 LIDAR Scan Rate": "40.0",
                    "V1 Throttle": "0.6",
                    "V1 Steering": "0.0",
                    "V1 Lap Count": "0",
                    "V1 Lap Time": f"{step * 0.025:.3f}",
                    "V1 Collisions": "0",
                }
                try:
                    client.emit("Bridge", data)
                    step += 1
                except Exception:
                    break
                time.sleep(0.01)

        threading.Thread(target=sim_loop, args=(client0, 0), daemon=True).start()
        threading.Thread(target=sim_loop, args=(client1, 1), daemon=True).start()
        time.sleep(0.05)

        results = track.step_all([(0.6, 0.0), (0.6, 0.0)])
        assert 0 in results and 1 in results
        assert results[0].position[2] > 0.0
        assert results[1].position[2] > 0.0
        assert results[0].true_speed == 8.5
        assert results[1].true_speed == 8.5

        results2 = track.step_all([(0.6, 0.0), (0.6, 0.0)])
        assert results2[0].step_id >= 2
        assert results2[1].step_id >= 2
        assert track.racers[0].step_counter >= 2
        assert track.racers[1].step_counter >= 2

        deadline = time.time() + 2.0
        while time.time() < deadline and (not received_0 or not received_1):
            time.sleep(0.05)
        assert len(received_0) >= 1
        assert len(received_1) >= 1
    finally:
        running = False
        try:
            if client0.connected:
                client0.disconnect()
            if client1.connected:
                client1.disconnect()
        except Exception:
            pass
        try:
            track.kill_all()
        except Exception:
            pass
