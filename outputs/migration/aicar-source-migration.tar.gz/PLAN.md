# AutoDRIVE RoboRacer Autonomous Sim-Racing: Architecture & Implementation Plan

This document synthesizes the system architecture, file layout, driver specifications, containerization strategy, and the **Mission Control UI** for the AutoDRIVE RoboRacer platform.

**Status snapshot:** Layer 1 (`src/layer1`) is implemented and live-verified. Layer 2 (`src/layer2`) is **implemented** per §6. Layer 3 plan: [`LAYER3.md`](LAYER3.md). Mission Control UI plan: [`UI.md`](UI.md). Prefer [README.md](README.md) for quick start; keep this file as the detailed design reference.

---

## 1. System Philosophy: The IDE & UI Separation

To combine algorithmic flexibility with operational control, the system divides responsibilities between your **IDE** and the **Mission Control Web UI**:

| In Your IDE (Code Development) | In the Mission Control UI (see [`UI.md`](UI.md); hub `:8090`) |
| :--- | :--- |
| • Designing neural network architectures (`src/layer3/`)<br>• Writing and tuning reward formulas (`src/layer2/rewards.py`)<br>• Adjusting hyperparameters (learning rate, entropy, discount factor)<br>• Version control and unit testing (`scripts/`) | • **Settings** mapped to `layer3.train` CLI flags<br>• **Start / stop** train via hub `Popen` (same as CLI)<br>• **Live telemetry** over WebSocket (non-interfering watch)<br>• Phase 6: fleet canvas (map / cars / LiDAR / collision **X**; hub telemetry only — see [`UI.md`](UI.md)) |

---

## 2. Project Directory Structure

```text
AiCar/
├── .gitignore                                 # Git ignore (venvs, binaries, cache, trajectory CSVs)
├── .dockerignore                              # Excludes .venv, .git, and cache from Docker build context
├── docker-compose.yml                         # A/B compose: brain + scalable sim (bridge, wide ports)
├── docker-compose.sim-gpu.yml                 # Optional NVIDIA GPU override for sim containers
├── docker/
│   ├── Dockerfile.sim                         # A — Ubuntu + Xvfb / Unity deps
│   ├── Dockerfile.brain                       # B — CUDA runtime + Python Layers 1–3
│   ├── entrypoint-sim.sh / entrypoint-brain.sh
│   ├── ready_stub.py                          # Default brain HTTP OK on :8090
│   └── README.md                              # Full Docker how-to
├── PLAN.md                                    # High-level architecture & roadmap
├── UI.md                                      # Mission Control UI implementation plan
├── README.md                                  # Repository overview + Layer 1 quick start
├── requirements.txt                           # Core dependencies (numpy, gymnasium, socketio, gevent, torch, sb3, fastapi)
├── scripts/
│   ├── demo.py                                # Live demos: layer1 | layer2 | check-env
│   └── test_layer1.py                         # Telemetry math + mock Socket.IO (1- and 2-car)
│
├── simulator/                                 # AutoDRIVE Unity Standalone (binaries mostly gitignored)
│   ├── README.md                              # Upstream simulator usage notes
│   ├── AutoDRIVE Simulator.x86_64             # Linux binary (optional)
│   └── windows/                               # Windows build used for Layer 1 verification
│       └── AutoDRIVE Simulator.exe
│
├── src/
│   ├── __init__.py
│   │
│   ├── layer1/                                # LAYER 1 (DONE): Simulator driver & track manager
│   │   ├── __init__.py                        # Exports RaceTrack, Racer, TelemetrySnapshot, TrajectoryLogger
│   │   ├── track.py                           # RaceTrack manager (geometry, checkpoints, fleet, kill)
│   │   ├── racer.py                           # gevent Socket.IO server, lockstep step/reset/kill, sim launch
│   │   ├── telemetry.py                       # Raw telemetry model, derived dynamics, CSV logger
│   │   └── README.md
│   │
│   ├── layer2/                                # LAYER 2 (DONE): Gymnasium wrapper — 1 env = 1 car
│   │   ├── __init__.py                        # Export AutoDriveEnv
│   │   ├── spaces.py                          # Obs/action spaces + snapshot→obs
│   │   ├── rewards.py                         # RewardConfig + compute_reward
│   │   ├── autodrive_env.py                   # gym.Env reset/step/close
│   │   └── README.md
│   │
│   ├── layer3/                                # PPO — see LAYER3.md
│   └── layer4/                                # PLANNED: Mission Control — see UI.md
│
├── assets/maps/                               # Vendored Porto/Berlin map assets (fleet Phase 6)
├── logs/trajectories/                         # Demo CSV exports (contents gitignored)
└── LAYER3.md                                  # Layer 3 implementation plan (PPO / extractor / train)
```

---

## 3. Docker Containerization Architecture

**A/B split** (implemented — details in [`docker/README.md`](docker/README.md)):

```text
Host                         Compose bridge `aicar`
────                         ─────────────────────
docker compose up
  --scale sim=2    ───────►  A × N  sim containers (Dockerfile.sim + Xvfb)
                             each: .x86_64 -batchmode -nographics -ip brain -port 4567+
                                      │
                                      ▼
                             B  brain container (Dockerfile.brain + CUDA)
                             ready stub :8090 · Socket.IO :4567–4582
                             train: --n-envs N --no-auto-launch
```

### Key Docker Components:
1. **`docker-compose.yml`**: `brain` + scalable `sim`; bridge network; ports `4567-4582` + `8090` (`8080` optional for in-B Vite HMR); volumes `./src`, `./scripts`, `./logs`, `./simulator`; GPU reservation on brain.
2. **`docker/Dockerfile.sim` / `entrypoint-sim.sh`**: Ubuntu + Xvfb/GL; launches one Unity binary per container; PORT from env or hostname index.
3. **`docker/Dockerfile.brain` / `ready_stub.py`**: CUDA runtime + pip; default HTTP OK on `:8090` (not auto-train).
4. **`docker-compose.sim-gpu.yml`**: optional NVIDIA GPU for sim containers.
5. **`.dockerignore`**: Excludes `.git`, `.venv`, `__pycache__`, and temp files from the build context.

---

## 4. Mission Control UI (`src/layer4/`)

**Authoritative plan:** [`UI.md`](UI.md).

v1 locks: **all Mission Control under `src/layer4/`** (not a top-level `ui/`), **FastAPI hub** on brain **B** (`:8090`, replaces ready stub), **Vite + React runs in Docker B** (prod: static in brain image on `:8090`; dev: HMR inside B / `layer4` service — not host-only), **TrainJob via `Popen`** of `python -m src.layer3.train` (UI does **not** call `step`), **full Settings UI from day 1** (all `train.py` CLI flags), train → `POST /telemetry` → hub → **WebSocket** watch. No Redis / `live.json` for v1. Fleet canvas = Phase 6 in [`UI.md`](UI.md) (map / cars / LiDAR / collision **X**; hub telemetry only; LiDAR angles measured in Phase 6). Hyperparam surgery = Phase N+ (**not day 1**).

---

## 5. Layer 1: The `layer1/` Driver & Track Manager

Layer 1 provides a clean, Pythonic interface to control and inspect the simulator with zero dependencies on Gymnasium or PyTorch.

```text
┌────────────────────────────────────────────────────────────────────────┐
│                        RaceTrack (track.py)                            │
│  - Holds Ground Truth: Centerline waypoints, total length L            │
│  - Checkpoints: Exposed num_gates, ordered gate crossing checks       │
│  - Owns & Manages: 1 or N Racer instances                             │
│  - Stepping: step_single(racer_id, th, st) and step_all(actions)      │
│  - Resets: reset_single(racer_id) and reset_all()                     │
│  - Process Control & Kill: kill_racer(racer_id) and kill_all()        │
│  - Export: save_all_trajectories(output_dir) in one single call       │
└───────────────────────────────────┬────────────────────────────────────┘
                                    │ Manages list of Racers
        ┌───────────────────────────┴───────────────────────────┐
        ▼                                                       ▼
┌───────────────────────────────┐       ┌───────────────────────────────┐
│       Racer (Port 4567)       │       │       Racer (Port 4568)       │
│  - Socket.IO Server           │       │  - Socket.IO Server           │
│  - Lockstep step() & reset()  │       │  - Lockstep step() & reset()  │
│  - Telemetry & Profiler       │       │  - Telemetry & Profiler       │
│  - Auto-launch Sim Process    │       │  - Auto-launch Sim Process    │
│  - kill() Process Termination │       │  - kill() Process Termination │
│  - Per-racer CSV Logger       │       │  - Per-racer CSV Logger       │
└───────────────┬───────────────┘       └───────────────┬───────────────┘
                ▼ (:4567)                               ▼ (:4568)
        [Unity Sim Process 0]                   [Unity Sim Process 1]
```

### Module Breakdown:

1. **`src/layer1/track.py` (`RaceTrack` Manager)**:
   * **Parameters**:
     * `num_racers: int = 1`: Number of parallel vehicle instances.
     * `base_port: int = 4567`: Starting port (instances bind to `base_port + i`).
     * `num_gates: int = 8`: Exposed checkpoint gate count (user directly controls gate frequency).
     * `waypoints: Optional[np.ndarray] = None`: Centerline coordinates $[(x_0, y_0), (x_1, y_1), \dots]$.
     * `simulator_path: Optional[str | Path] = None`: Path to Unity executable.
     * `auto_launch: bool = False`: Automatic background process execution.
     * `headless: bool = True`: Launch with `-batchmode -nographics`.
   * **Methods**:
     * `get_frenet_progress(x, y) -> (s, d)`: Arc-length track distance ($s$) and lateral offset ($d$).
     * `update_checkpoints(racer_id, s) -> (gate_passed, lap_completed)`: Validates sequential gate crossing ($0 \to 1 \to 2 \dots$).
     * `step_single(racer_id, throttle, steering)`: Step one specific vehicle.
     * `step_all(actions)`: Step all vehicles simultaneously.
     * `reset_single(racer_id)` & `reset_all()`: Teleports cars back to the grid and zeroes stats.
     * `kill_racer(racer_id)`: Terminates a specific racer subprocess (SIGTERM/SIGKILL), closes its Socket.IO server, and removes it from the active fleet while preserving its logs.
     * `kill_all()`: Shuts down all simulator processes and stops all background servers.
     * `save_all_trajectories(output_dir)`: Exports CSV logs for **all racers** into a folder in one single call (`output_dir/racer_0.csv`, `output_dir/racer_1.csv`).

2. **`src/layer1/racer.py` (`Racer` Class)**:
   * **Parameters**: `racer_id`, `port`, `simulator_path`, `auto_launch`, `headless`, `step_timeout`.
   * **Attributes**: `telemetry` (`TelemetrySnapshot`), `logger` (`TrajectoryLogger`), profiler metrics (`step_latency_ms`, `steps_per_second`, `real_time_factor`).
   * **Transport**: `socketio.Server(async_mode="gevent")` + `gevent.pywsgi` + `WebSocketHandler`. This RoboRacer Windows build speaks **Engine.IO v4** (`python-socketio` 5.x / `python-engineio` 4.x). Commands are returned only via `sio.emit('Bridge', {string values})` (no ACK return payload). A small auto-connect shim handles Unity clients that emit `Bridge` before a formal namespace connect.
   * **Methods**:
     * `_start_server()`: Starts background gevent Socket.IO server on `0.0.0.0:port` (server object created on the server thread — required on Windows).
     * `step(throttle, steering)`: Buffers clamped commands, waits for next `'Bridge'` frame (turn-based lockstep), updates profiler, and returns `TelemetrySnapshot`.
     * `reset()`: Sets `V1 Reset` for the next Bridge reply (`"True"` / `"False"`), waits for acknowledgment, returns state.
     * `kill()`: Terminates the child OS process, stops the gevent server, and releases the port.
     * `save_trajectory(file_path)`: Exports this vehicle's trajectory history to CSV.


3. **`src/layer1/telemetry.py`**:
   * **`TelemetrySnapshot`**:
     * 100% raw data: position $(x, y, z)$, orientation quaternion $(x, y, z, w)$, linear/angular velocities, linear acceleration, wheel encoders (left/right), 1,080 LiDAR beams, scan rate, actuator states, lap stats, collisions.
     * Derived metrics: `true_speed`, `heading_yaw`, `v_long`, `v_lat`, `slip_angle`, `lateral_g`.
   * **`TrajectoryLogger`**: In-memory buffer logging step, timestamp, $(x, y, z)$, speed, slip angle, throttle, steering, encoders, and lap stats; exports to CSV.

4. **`src/layer1/__init__.py`**:
   * Exports `RaceTrack`, `Racer`, `TelemetrySnapshot`, and `TrajectoryLogger`.

---

## 6. Layer 2: Gymnasium Environment (`src/layer2/`)

Layer 2 wraps Layer 1 so a learning algorithm (e.g. PPO via Stable-Baselines3) can train without knowing Socket.IO exists. Gymnasium is only the shared `reset` / `step` interface; the env turns telemetry into **observation**, **reward**, and **episode-over** signals.

**Data flow:** Unity → Layer 1 (`TelemetrySnapshot`) → `autodrive_env.py` gathers facts → `rewards.compute_reward(...)` → score for the learner. To reward something Layer 1 does not expose yet: extend Layer 1, or derive it in the env from existing fields / external files, then pass it into `rewards.py`.

### Locked design decisions

| Topic | Decision |
| :--- | :--- |
| Env ↔ car | **Strict 1 Gym env = 1 racer.** We are **not** putting multiple cars inside one env. Parallelism later = many env *processes*, each with its own headless sim (e.g. SB3 `SubprocVecEnv`) |
| Default launch | **Headless** (watching is Mission Control UI later, not the Unity window) |
| LiDAR | **Full live scan**, normalized; no downsampling for PPO |
| Waypoints / Frenet progress reward | **Deferred** — reward Phase 2; v1 does not require a centerline map |
| Crash policy | **Do not end the episode on collision.** Keep `collision_penalty` in config but **default `0.0`**. Pressure comes from lost forward progress + stagnation truncation. Wall tax is optional later |
| Episode end | **Stagnation truncation** (no meaningful forward progress for a configured idle window). Optional hard **max-steps** cap (`max_episode_steps`; **default `0` = disabled**). Not a fixed “one lap timer” |
| Control rate | Unity physics ~**40 Hz**. Default **`frame_skip=1`** (~40 Hz actions). `frame_skip` must be `>= 1` (`0` is invalid). Option e.g. `2` → ~20 Hz |

### Explicitly out of scope for Layer 2

* Multi-car / multi-agent **inside** a single `AutoDriveEnv`  
* PPO, neural nets, training loops (Layer 3)  
* Mission Control UI  
* Waypoints, Frenet \(s,d\), gates, lap bonuses (reward Phase 2)

### Modules (ship with Layer 2)

| File | Role |
| :--- | :--- |
| `src/layer2/__init__.py` | Export `AutoDriveEnv` (and maybe `RewardConfig`) |
| `src/layer2/spaces.py` | Action/obs space definitions + `TelemetrySnapshot` → obs helpers |
| `src/layer2/rewards.py` | `RewardConfig` + `compute_reward` (main file for tuning scores) |
| `src/layer2/autodrive_env.py` | `gym.Env`: `reset` / `step` / `close`; gathers facts; calls Layer 1 |
| `scripts/demo.py check-env` | SB3 / Gymnasium `check_env` live smoke |
| `src/layer2/README.md` | Layer 2 summary, layout, file/API docs, how-to-use |
| `src/layer1/README.md` | Layer 1 summary, layout, file/API docs |

### Observation / action (v1)

* **Observation** (`Dict`):
  * `"lidar"`: shape `(1081,)` for current Bridge packets, values in \([0, 1]\); 1080-beam documented packets are resampled to this canonical shape
  * `"state"`: shape `(9,)`: individually scaled body velocity, yaw rate, acceleration, measured actuators, and previous commands
* **Action**: `Box(-1, 1, shape=(2,))` → `[throttle, steering]`

### Reward sketch (v1, no waypoints)

* **Primary signal:** forward progress proxy (e.g. \(v_{\text{long}}\) or forward displacement). Stagnation truncates the episode — main “you’re stuck” pressure (including after crashes).
* **`collision_penalty`:** present in `RewardConfig`, **default `0.0`**. Crash ≠ automatic lose.
* Optional weights (may also default to `0`): slip, steering jerk.
* Episode continues after hits unless stagnating or max steps hit.

**How to add a new reward/penalty later (edit `rewards.py`):**

1. Add a weight on `RewardConfig` (default `0.0` if unused).
2. In `compute_reward(...)`, add a term when the condition is true.
3. If you need a new **fact**, either expose it on `TelemetrySnapshot` (Layer 1), derive it in `autodrive_env.py` from existing snap fields, or load external data (e.g. waypoint file) in the env — then pass that fact into `compute_reward`.
4. Tune by changing config numbers, not rewriting the env loop.

### Termination vs truncation

* **Terminated:** unused for crashes in v1 (reserve for rare hard failures only if we add any later)
* **Truncated:** stagnation window, or optional absolute max-steps safety cap (`max_episode_steps > 0`)  
* **`reset()`:** called when a *new episode* starts (after truncate). That calls Layer 1 reset (teleport to grid). Mid-episode crashes do **not** by themselves call Unity reset.

### Still fuzzy (implementation defaults chosen)

These were open in design; v1 code uses:

1. **Stagnation:** `|v_long| < 0.15` m/s for **200** consecutive env steps (~5 s at 40 Hz with `frame_skip=1`).
2. **Forward reward:** `forward_scale * v_long` with `forward_scale=1.0`.
3. **Connect wait:** **60** s timeout on env init when launching / expecting a client.
4. **`info` dict** (diagnostics only — **not** fed to the policy): `step`, `idle_steps`, `reward`, `v_long`, `true_speed`, `collision`, `collision_event`, `collision_count`, `position`, plus `truncate_reason` when truncated.
5. **State scaling:** none beyond LiDAR → \([0,1]\); kinematic state left as raw floats (deferred).
6. **`max_episode_steps`:** default **`0`** (disabled); set positive for a hard cap.
7. **Simulator path:** auto-detect Windows `.exe` vs Docker Linux `.x86_64`, or `AICAR_SIMULATOR_PATH`.

Full teaching docs: [`src/layer2/README.md`](src/layer2/README.md).

### Deferred (later phases)

* Track waypoints, Frenet \(s,d\), checkpoint gates, lap-completion bonus  
* LiDAR downsampling options  
* Layer 3: see [`LAYER3.md`](LAYER3.md) (PPO + 1D-CNN / MultiInputPolicy)  
* Parallel vectorized training (many 1-car envs, not multi-car-in-one-env)

---

## 7. Verification Plan

### Layer 1 — Verified

1. **Unit / mock tests** (`scripts/test_layer1.py`):
   * Quaternion / slip / Frenet math; mock Socket.IO lockstep; dual mock clients.
2. **Live headless smoke** (`python scripts/demo.py layer1 --headless`):
   * Auto-connect via `-ip` / `-port`; continuous Bridge frames; speed > 0; CSV export.
3. **Live headed multi-instance** (`python scripts/demo.py layer1 --racers 2`):
   * Two GUI windows on ports `4567` / `4568`; both connect and drive in lockstep.
4. **Live control smoke** (headless, 2 cars):
   * `reset_all` / `reset_single`; `kill_racer(i)` while sibling keeps stepping; `kill_all`.

### Later layers — Pending

5. **Layer 2 Gymnasium — Implemented**:
   * `src/layer2/` + `scripts/demo.py layer2|check-env` + layer READMEs
   * Live `check_env` still requires a headless sim binary when you run the checker
6. **Mission Control UI Smoke Test**:
   * Launch Layer 4 hub in brain B, open `http://localhost:8090`, verify Settings / start/stop / live telemetry (fleet canvas = Phase 6 per [`UI.md`](UI.md)).
7. **Docker Build & Run Verification**:
   * `docker compose up --build`, GPU via `nvidia-smi`, Mission Control on port **8090**.
